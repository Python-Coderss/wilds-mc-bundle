"""Telegram bot: long polling, command handling, and state notifications.

Long polling is used instead of a webhook because the Space only exposes one
HTTP port and a webhook would need a public, secret URL for Telegram.
"""
from __future__ import annotations

import threading
import time
from typing import Any

import httpx

from . import config, provision, store

HELP = """Wilds control room
/status  - server state, players, uptime
/wake    - start the server now
/sleep   - save and stop the server
/players - who is online
/ip      - connection addresses, Education connection ID
/stats   - wake/sleep counters
/backup  - send a state.db snapshot to this chat
/help    - this message"""


class TelegramBot:
    def __init__(self, server, token: str | None = None, default_chat: str | None = None) -> None:
        self.server = server
        self.token = token if token is not None else config.TELEGRAM_TOKEN
        self.default_chat = (default_chat if default_chat is not None else config.TELEGRAM_CHAT_ID) or ""
        self.base = f"https://api.telegram.org/bot{self.token}" if self.token else ""
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._client = httpx.Client(timeout=45.0, headers={"User-Agent": "wilds-space/1.0"})
        self._offset = 0

    # ------------------------------------------------------------- lifecycle
    @property
    def enabled(self) -> bool:
        return bool(self.token)

    def start(self) -> None:
        if not self.enabled:
            store.log_event("telegram", "disabled: no TELEGRAM_BOT_TOKEN")
            return
        self._thread = threading.Thread(target=self._loop, name="telegram", daemon=True)
        self._thread.start()
        if config.TELEGRAM_BACKUP_HOURS > 0:
            threading.Thread(target=self._backup_loop, name="telegram-backup", daemon=True).start()
        store.log_event("telegram", "long polling started")

    def stop(self) -> None:
        self._stop.set()
        try:
            self._client.close()
        except Exception:
            pass

    # ------------------------------------------------------------- allowlist
    def owner_chat(self) -> str:
        if self.default_chat:
            return self.default_chat
        return store.get_kv("owner_chat_id", "")

    def _is_allowed(self, chat_id: str) -> bool:
        owner = self.owner_chat()
        if owner:
            return str(chat_id) == str(owner)
        # First chat to talk to the bot claims it; stored in SQLite.
        store.set_kv("owner_chat_id", str(chat_id))
        store.register_chat(str(chat_id))
        return True

    # ---------------------------------------------------------------- polling
    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                response = self._client.get(
                    f"{self.base}/getUpdates",
                    params={"timeout": 25, "offset": self._offset,
                            "allowed_updates": '["message"]'},
                )
                payload = response.json()
                if not payload.get("ok"):
                    time.sleep(5)
                    continue
                for update in payload.get("result", []):
                    self._offset = update.get("update_id", 0) + 1
                    message = update.get("message") or {}
                    try:
                        self._handle(message)
                    except Exception as exc:  # never kill the poller
                        store.log_event("telegram_error", str(exc)[:200])
            except httpx.HTTPError:
                time.sleep(5)
            except Exception:
                time.sleep(5)

    def _handle(self, message: dict[str, Any]) -> None:
        chat = message.get("chat") or {}
        chat_id = str(chat.get("id", ""))
        text = (message.get("text") or "").strip()
        if not chat_id or not text.startswith("/"):
            return
        if not self._is_allowed(chat_id):
            self._send(chat_id, "This bot is locked to its owner. Set TELEGRAM_CHAT_ID to change that.")
            return

        store.register_chat(chat_id, (message.get("from") or {}).get("username", ""))
        store.bump("telegram_commands")
        command = text.split()[0].split("@")[0].lower()
        handler = {
            "/start": self._cmd_help,
            "/help": self._cmd_help,
            "/status": self._cmd_status,
            "/wake": self._cmd_wake,
            "/sleep": self._cmd_sleep,
            "/players": self._cmd_players,
            "/ip": self._cmd_ip,
            "/stats": self._cmd_stats,
            "/backup": self._cmd_backup,
        }.get(command, self._cmd_help)
        self._send(chat_id, handler())

    # --------------------------------------------------------------- commands
    def _cmd_help(self) -> str:
        return HELP

    def _cmd_status(self) -> str:
        status = self.server.status()
        lines = [
            f"State: {status['state']}",
            f"Players: {status['player_count']}/{config.MAX_PLAYERS}",
            f"Version: Java {status['version']} (protocol {status['protocol']})",
        ]
        if status["state"] == "running":
            lines.append(f"Uptime: {_human(status['uptime_seconds'])}")
        if status["state"] == "starting":
            lines.append(f"Booting for {status['booting_seconds']}s")
        if status["players"]:
            lines.append("Online: " + ", ".join(status["players"]))
        if status["last_error"]:
            lines.append(f"Last error: {status['last_error']}")
        return "\n".join(lines)

    def _cmd_wake(self) -> str:
        result = self.server.wake(reason="telegram")
        if result["started"]:
            return "Waking the server. First boot can take a few minutes; the lobby MOTD updates meanwhile."
        return f"Already {result['state']}."

    def _cmd_sleep(self) -> str:
        result = self.server.sleep(reason="telegram")
        if result["stopped"]:
            return "Saving the world and stopping the server."
        return f"Nothing to stop (state: {result['state']})."

    def _cmd_players(self) -> str:
        online, maximum, names = self.server.online_players()
        if not names:
            return f"No players online (0/{maximum})."
        return f"{online}/{maximum} online:\n" + "\n".join(f"- {name}" for name in names)

    def _cmd_ip(self) -> str:
        lines = []
        if config.MC_PUBLIC_ADDRESS:
            lines.append(f"Java: {config.MC_PUBLIC_ADDRESS}")
        if config.BEDROCK_PUBLIC_ADDRESS:
            lines.append(f"Bedrock: {config.BEDROCK_PUBLIC_ADDRESS}")
        if config.EDU_ENABLED:
            connection_id = provision.edu_connection_id()
            if connection_id:
                lines.append(f"Education Edition: connection ID {connection_id}")
            else:
                lines.append("Education Edition: connection ID is created on the first boot")
        if not lines:
            lines.append(
                "No public tunnel configured yet. Set PLAYIT_SECRET (see the Space README) "
                "and MC_PUBLIC_ADDRESS here."
            )
        lines.append(f"Dashboard: {config.SPACE_URL}")
        return "\n".join(lines)

    def _cmd_stats(self) -> str:
        counters = store.counters()
        return (
            f"Wakes: {counters['wakes']}\n"
            f"Sleeps: {counters['sleeps']}\n"
            f"Commands handled: {counters['telegram_commands']}"
        )

    def _cmd_backup(self) -> str:
        if not self.enabled:
            return "Set TELEGRAM_BOT_TOKEN first."
        if not self.owner_chat():
            return "No owner chat yet: send /start from the chat that should own this bot."
        if self.backup():
            return "Snapshot sent. Keep it: it holds the allowlist, counters and events."
        return "Snapshot failed; check the Space logs."

    # ----------------------------------------------------------------- backup
    def _backup_path(self):
        return config.DB_PATH if config.DB_PATH.exists() else None

    def backup(self, chat_id: str = "") -> bool:
        """Send state.db to the owner chat. Survives a /data wipe off-platform."""
        if not self.enabled:
            return False
        target = chat_id or self.owner_chat()
        path = self._backup_path()
        if not target or path is None:
            return False
        return self._send_document(target, path)

    def _backup_loop(self) -> None:
        interval = config.TELEGRAM_BACKUP_HOURS * 3600
        while not self._stop.wait(interval):
            if self.backup():
                store.log_event("telegram", "state.db snapshot sent")

    # ------------------------------------------------------------------ send
    def _send(self, chat_id: str, text: str) -> None:
        if not self.enabled or not chat_id:
            return
        try:
            self._client.post(
                f"{self.base}/sendMessage",
                json={"chat_id": chat_id, "text": text[:4000], "disable_web_page_preview": True},
            )
        except httpx.HTTPError:
            pass

    def _send_document(self, chat_id: str, path) -> bool:
        try:
            with open(path, "rb") as handle:
                response = self._client.post(
                    f"{self.base}/sendDocument",
                    data={
                        "chat_id": chat_id,
                        "caption": f"wilds state.db · {config.VERSION} · {int(time.time())}",
                    },
                    files={"document": (path.name, handle, "application/octet-stream")},
                )
            return bool(response.json().get("ok"))
        except Exception:
            return False

    def notify(self, text: str) -> None:
        """Broadcast to the owner plus any chat that has registered."""
        if not self.enabled:
            return
        recipients: list[str] = []
        owner = self.owner_chat()
        if owner:
            recipients.append(owner)
        for chat in store.chats():
            chat_id = str(chat["chat_id"])
            if chat_id not in recipients:
                recipients.append(chat_id)
        for chat_id in recipients:
            self._send(chat_id, text)


def _human(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes}m {sec}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m"
