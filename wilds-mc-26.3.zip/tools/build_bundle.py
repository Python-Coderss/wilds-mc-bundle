#!/usr/bin/env python3
"""Build the deployable zip for a host without git.

    python3 tools/build_bundle.py

Writes dist/wilds-mc-26.3.zip with the server, docs and deploy scripts, skipping
the things that must never ship (secrets, local data, caches, the bundle itself).
"""
from __future__ import annotations

import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
STAGE = ROOT / "dist"
NAME = "wilds-mc-26.3.zip"

# Whitelist of what ships. A scratch checkout or a stray folder in the working
# tree must never leak into a published bundle, so unknown top-level entries are
# dropped rather than filtered against a growing skip list.
SHIP = {
    "app", "tools", "docs", "scripts", ".github",
    "Dockerfile", "README.md", "install.sh", "wake_proxy.py",
    ".env.example", ".dockerignore", ".gitignore",
}
SKIP_DIRS = {"__pycache__", "data", "dist", ".git", ".venv", "venv"}
SKIP_FILES = {".env", ".DS_Store", "Thumbs.db"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".zip", ".part"}


def keep(relative: Path) -> bool:
    if relative.parts[0] not in SHIP:
        return False
    if any(part in SKIP_DIRS for part in relative.parts[:-1]):
        return False
    if relative.name in SKIP_FILES or relative.suffix in SKIP_SUFFIXES:
        return False
    return True


def main() -> int:
    STAGE.mkdir(parents=True, exist_ok=True)
    target = STAGE / NAME
    entries: list[str] = []

    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(ROOT.rglob("*")):
            if not path.is_file():
                continue
            relative = path.relative_to(ROOT)
            if not keep(relative):
                continue
            archive.write(path, relative.as_posix())
            entries.append(relative.as_posix())

    missing = [
        required
        for required in ("install.sh", "Dockerfile", "app/main.py",
                         "scripts/entrypoint.sh",
                         "docs/JAVA_MODS.md", ".env.example")
        if required not in entries
    ]
    size = target.stat().st_size
    print(f"{target.relative_to(ROOT)}: {len(entries)} files, {size / 1024:.0f} KiB")
    for name in entries:
        if name.count("/") == 0:
            print(f"  {name}")
    if missing:
        print("MISSING: " + ", ".join(missing))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
