"""A tiny RCON client (Source RCON protocol) for Paper.

Only two things are needed from the server console: `list` for the player
count and `save-all`/`stop` for clean sleeps, so a full library would be
overkill. The packet format is stable and small enough to implement here.
"""
from __future__ import annotations

import re
import socket
import struct

AUTH = 3
COMMAND = 2


def pack(request_id: int, packet_type: int, body: str) -> bytes:
    payload = struct.pack("<ii", request_id, packet_type) + body.encode("utf-8") + b"\x00\x00"
    return struct.pack("<i", len(payload)) + payload


def recv_exact(sock: socket.socket, size: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < size:
        chunk = sock.recv(size - len(chunks))
        if not chunk:
            raise ConnectionError("RCON connection closed")
        chunks.extend(chunk)
    return bytes(chunks)


def read_packet(sock: socket.socket) -> tuple[int, int, str]:
    (length,) = struct.unpack("<i", recv_exact(sock, 4))
    if length < 10 or length > 4 * 1024 * 1024:
        raise ValueError(f"unreasonable RCON packet length: {length}")
    data = recv_exact(sock, length)
    request_id, packet_type = struct.unpack("<ii", data[:8])
    body = data[8:-2].decode("utf-8", errors="replace")
    return request_id, packet_type, body


def command(text: str, *, host: str = "127.0.0.1", port: int = 25575,
            password: str = "", timeout: float = 5.0) -> str:
    """Run one console command and return the combined response text."""
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(timeout)
        sock.sendall(pack(1, AUTH, password))
        request_id, _, _ = read_packet(sock)
        if request_id == -1:
            raise PermissionError("RCON authentication failed")

        sock.sendall(pack(2, COMMAND, text))
        sock.sendall(pack(3, COMMAND, ""))  # sentinel so we know when output ends
        output: list[str] = []
        while True:
            request_id, _, body = read_packet(sock)
            if request_id == 3:
                break
            if request_id == 2 and body:
                output.append(body)
        return "".join(output)


_PLAYER_RE = re.compile(r"There are (\d+) of a max(?: of)? (\d+) players online:?\s*(.*)", re.S)


def parse_list(response: str) -> tuple[int, int, list[str]]:
    """Parse the vanilla `list` output into (online, max, names)."""
    match = _PLAYER_RE.search(response or "")
    if not match:
        return 0, 0, []
    online, maximum, names = int(match.group(1)), int(match.group(2)), match.group(3)
    parsed = [name.strip() for name in names.split(",") if name.strip()]
    return online, maximum, parsed
