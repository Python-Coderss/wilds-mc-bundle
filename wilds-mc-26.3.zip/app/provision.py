"""Provision the Minecraft server files inside DATA_DIR.

Downloads are resolved from the vendors' own metadata at first boot instead of
being hard-coded, so a restart picks up the current stable build for the
pinned Minecraft version.

  Paper    -> https://fill.papermc.io (v3 API, STABLE channel only)
  Geyser   -> https://download.geysermc.org (Spigot/Paper build)
  Floodgate-> https://download.geysermc.org (Spigot/Paper build)

Config defaults are extracted from the shipped jars and then patched, which
keeps every key the upstream version expects (hand-written configs break on
schema changes).
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import threading
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

from . import config

PAPER_BUILDS = f"https://fill.papermc.io/v3/projects/paper/versions/{config.VERSION}/builds"
GEYSER_META = "https://download.geysermc.org/v2/projects/{project}/versions/latest/builds/latest"
GEYSER_JAR = "https://download.geysermc.org/v2/projects/{project}/versions/latest/builds/latest/downloads/spigot"
USER_AGENT = f"wilds-space/{config.VERSION} (+https://huggingface.co/spaces)"

_LOCK = threading.Lock()
_CURRENT: dict[str, Any] = {}


def _get_json(url: str, timeout: float = 60) -> Any:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def _download(url: str, destination: Path, sha256: str | None = None) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    partial = destination.with_suffix(destination.suffix + ".part")
    digest = hashlib.sha256()
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=180) as response, open(partial, "wb") as handle:
        while True:
            chunk = response.read(1 << 20)
            if not chunk:
                break
            digest.update(chunk)
            handle.write(chunk)
    if sha256 and digest.hexdigest().lower() != sha256.lower():
        partial.unlink(missing_ok=True)
        raise RuntimeError(f"checksum mismatch for {url}")
    os.replace(partial, destination)


def _stamp_value(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8").strip()
    except OSError:
        return ""


def ensure_paper(force: bool = False) -> dict[str, Any]:
    builds = _get_json(PAPER_BUILDS)
    if not isinstance(builds, list) or not builds:
        raise RuntimeError("Paper API returned no builds")
    stable = [build for build in builds if str(build.get("channel", "")).upper() == "STABLE"]
    build = (stable or builds)[0]
    downloads = build.get("downloads") or {}
    entry = downloads.get("server:default") or next(iter(downloads.values()), None)
    if not entry or not entry.get("url"):
        raise RuntimeError("Paper build has no server download")

    jar = config.SERVER_DIR / "paper.jar"
    stamp = config.SERVER_DIR / ".paper-build"
    if not force and jar.exists() and _stamp_value(stamp) == str(build.get("id")):
        return {"build": build.get("id"), "channel": build.get("channel"), "cached": True}

    _download(entry["url"], jar, (entry.get("checksums") or {}).get("sha256"))
    stamp.write_text(f"{build.get('id')}\n", encoding="utf-8")
    return {"build": build.get("id"), "channel": build.get("channel"), "cached": False}


def ensure_plugin(project: str, filename: str, force: bool = False) -> dict[str, Any]:
    meta = _get_json(GEYSER_META.format(project=project))
    build = str(meta.get("build"))
    entry = (meta.get("downloads") or {}).get("spigot") or {}
    jar = config.PLUGIN_DIR / filename
    stamp = config.PLUGIN_DIR / f".{project}-build"
    if not force and jar.exists() and _stamp_value(stamp) == build:
        return {"build": build, "version": meta.get("version"), "cached": True}
    _download(GEYSER_JAR.format(project=project), jar, entry.get("sha256"))
    stamp.write_text(build + "\n", encoding="utf-8")
    return {"build": build, "version": meta.get("version"), "cached": False}


# ------------------------------------------------------------------ crossplay
# Education Edition does not speak RakNet at all: 26.x clients use NetherNet
# (WebRTC) and only join through a Geyser build that implements it. EduGeyser
# is that fork, and it still serves regular Bedrock clients, so one plugin
# covers Java + Bedrock + Education instead of running two Geyser copies.

_CONNECTION_ID_RE = re.compile(r"^\d{10,18}$")


def _geyser_config_dir() -> Path:
    """Locate Geyser's data folder.

    Upstream uses plugins/Geyser-Spigot. The fork has shipped under its own
    folder name, so probe the known names first and then any folder that already
    holds NetherNet state, instead of assuming one layout.
    """
    for name in ("Geyser-Spigot", "EduGeyser-Spigot", "geyser"):
        candidate = config.PLUGIN_DIR / name
        if candidate.is_dir():
            return candidate
    for candidate in config.PLUGIN_DIR.glob("*/nethernet"):
        if candidate.is_dir():
            return candidate.parent
    return config.PLUGIN_DIR / "Geyser-Spigot"


def _plugin_jar(*names: str) -> Path:
    for name in names:
        candidate = config.PLUGIN_DIR / name
        if candidate.exists():
            return candidate
    return config.PLUGIN_DIR / (names[0] if names else "Geyser-Spigot.jar")


def _forget(*stamps: Path) -> None:
    for stamp in stamps:
        stamp.unlink(missing_ok=True)


def _download_pinned(url: str, jar: Path, stamp: Path, version: str, force: bool) -> dict[str, Any]:
    """Download a release asset and remember the tag, so restarts stay cheap."""
    if not force and jar.exists() and _stamp_value(stamp) == version:
        return {"version": version, "cached": True}
    _download(url, jar)  # these forks do not publish a checksum file
    stamp.write_text(version + "\n", encoding="utf-8")
    return {"version": version, "cached": False}


def ensure_edu_geyser(force: bool = False) -> dict[str, Any]:
    """Install the EduGeyser fork in place of upstream Geyser.

    The jar keeps the upstream filename because the plugin id (and therefore the
    config folder) is Geyser-Spigot; dropping the official stamp guarantees the
    fork's build is fetched instead of reusing an already-good official jar.
    """
    _forget(config.PLUGIN_DIR / ".geyser-build")
    result = _download_pinned(
        config.EDUGEYSER_URL,
        config.PLUGIN_DIR / "Geyser-Spigot.jar",
        config.PLUGIN_DIR / ".edugeyser-version",
        config.EDUGEYSER_VERSION,
        force,
    )
    result["source"] = "edugeyser"
    return result


def ensure_edu_floodgate(force: bool = False) -> dict[str, Any]:
    """EduFloodgate gives Education players a Java identity on online-mode."""
    _forget(config.PLUGIN_DIR / ".floodgate-build")
    result = _download_pinned(
        config.EDUFLOODGATE_URL,
        config.PLUGIN_DIR / "floodgate.jar",
        config.PLUGIN_DIR / ".edufloodgate-version",
        config.EDUFLOODGATE_VERSION,
        force,
    )
    result["source"] = "edufloodgate"
    return result


def edu_connection_id(create: bool = False) -> str:
    """The NetherNet connection ID Education Edition players type in.

    Geyser stores it next to a signaling account identity it manages itself, so
    only the number is ever touched and the rest of the file is preserved. It is
    generated once (18 digits) and must stay stable: players save it, and
    regenerating it locks them out until they are told the new number.
    """
    path = _geyser_config_dir() / "nethernet" / "connection-id.yml"
    data = _load_yaml(path) if path.exists() else {}
    if path.exists() and not data:
        return ""  # never clobber a file we failed to parse

    stored = str(data.get("connection-id", "")).strip()
    pinned = config.EDU_CONNECTION_ID.strip()

    if pinned and not _CONNECTION_ID_RE.match(pinned):
        pinned = ""

    if pinned:
        if stored != pinned and create:
            data["connection-id"] = pinned
            path.parent.mkdir(parents=True, exist_ok=True)
            _dump_yaml(path, data)
        return pinned
    if _CONNECTION_ID_RE.match(stored):
        return stored
    if not create:
        return ""

    generated = f"{secrets.randbelow(10**18):018d}"
    data["connection-id"] = generated
    path.parent.mkdir(parents=True, exist_ok=True)
    _dump_yaml(path, data)
    return generated


def ensure_edu_connection() -> str:
    return edu_connection_id(create=True)


SERVER_PROPERTIES: dict[str, str] = {
    "motd": config.MOTD,
    "server-port": str(config.SERVER_PORT),
    "server-ip": "127.0.0.1",
    "max-players": str(config.MAX_PLAYERS),
    "online-mode": "true",
    "enforce-secure-profile": "false",
    "enable-rcon": "true",
    "rcon.port": str(config.RCON_PORT),
    "rcon.password": config.RCON_PASSWORD,
    "broadcast-rcon-to-ops": "false",
    "view-distance": "8",
    "simulation-distance": "6",
    "spawn-protection": "0",
    "allow-flight": "true",
    "enable-status": "true",
    "network-compression-threshold": "256",
    "difficulty": "normal",
    "level-name": "world",
}


def _upsert(lines: list[str], key: str, value: str) -> list[str]:
    prefix = f"{key}="
    for index, line in enumerate(lines):
        if line.strip().startswith(prefix):
            lines[index] = f"{key}={value}"
            return lines
    lines.append(f"{key}={value}")
    return lines


def ensure_server_properties() -> None:
    path = config.SERVER_DIR / "server.properties"
    if path.exists():
        lines = path.read_text(encoding="utf-8").splitlines()
    else:
        lines = [
            "# Generated by the Space; managed keys are updated on every boot.",
            "# Minecraft server properties reference: https://minecraft.wiki/w/Server.properties",
        ]
        for key, value in SERVER_PROPERTIES.items():
            lines.append(f"{key}={value}")
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return

    # Managed keys only. Everything else is left exactly as the operator set it.
    for key in (
        "server-port",
        "server-ip",
        "enable-rcon",
        "rcon.port",
        "rcon.password",
        "broadcast-rcon-to-ops",
        "enforce-secure-profile",
        "max-players",
    ):
        lines = _upsert(lines, key, SERVER_PROPERTIES[key])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def ensure_extra_plugins(force: bool = False) -> dict[str, Any]:
    """Install operator-supplied Paper plugins (see EXTRA_PLUGINS).

    These are Bukkit plugins, not mods: JEI and Xaero's Minimap run on the
    client. The useful server counterparts are recipe-sync (JEI) and
    waypoint-sync (Xaero's) plugins; both are plain jars dropped in plugins/.
    """
    installed: dict[str, Any] = {}
    for filename, url in config.EXTRA_PLUGINS:
        jar = config.PLUGIN_DIR / filename
        stamp = config.PLUGIN_DIR / f".{filename}.url"
        try:
            if not force and jar.exists() and _stamp_value(stamp) == url:
                installed[filename] = {"cached": True}
                continue
            _download(url, jar)
            stamp.write_text(url + "\n", encoding="utf-8")
            installed[filename] = {"cached": False}
        except Exception as exc:  # a broken optional plugin must not block boot
            installed[filename] = {"error": str(exc)}
    return installed


def ensure_eula() -> None:
    path = config.SERVER_DIR / "eula.txt"
    text = ""
    if path.exists():
        text = path.read_text(encoding="utf-8")
    if "eula=true" not in text.replace(" ", "").lower():
        path.write_text(
            "# By setting eula=true you agree to the Minecraft EULA:\n"
            "# https://www.minecraft.net/en-us/eula\n"
            "eula=true\n",
            encoding="utf-8",
        )


def _jar_default_config(jar: Path, name: str = "config.yml") -> str | None:
    """Read the default config the plugin ships inside its own jar."""
    try:
        with zipfile.ZipFile(jar) as archive:
            try:
                return archive.read(name).decode("utf-8")
            except KeyError:
                for member in archive.namelist():
                    if member.endswith("/" + name):
                        return archive.read(member).decode("utf-8")
    except (OSError, zipfile.BadZipFile):
        return None
    return None


def _load_yaml(path: Path) -> dict[str, Any]:
    import yaml

    try:
        loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        loaded = None
    return loaded if isinstance(loaded, dict) else {}


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    import yaml

    path.write_text(
        yaml.safe_dump(data, sort_keys=False, allow_unicode=True, default_flow_style=False),
        encoding="utf-8",
    )


def ensure_geyser_config() -> None:
    config_path = _geyser_config_dir() / "config.yml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if not config_path.exists():
        defaults = _jar_default_config(_plugin_jar("Geyser-Spigot.jar", "EduGeyser-Spigot.jar"))
        if defaults:
            config_path.write_text(defaults, encoding="utf-8")
    if not config_path.exists():
        return

    data = _load_yaml(config_path)
    if not data:
        return  # unreadable/empty default: leave it for Geyser to regenerate
    bedrock = data.setdefault("bedrock", {})
    bedrock["port"] = config.BEDROCK_PORT
    bedrock["clone-remote-port"] = False
    bedrock["motd1"] = config.BEDROCK_MOTD
    bedrock["server-name"] = config.BEDROCK_MOTD
    remote = data.setdefault("remote", {})
    remote["address"] = "127.0.0.1"
    remote["port"] = config.SERVER_PORT
    remote["auth-type"] = "floodgate"
    _dump_yaml(config_path, data)


def ensure_floodgate_config() -> None:
    config_path = config.PLUGIN_DIR / "floodgate" / "config.yml"
    config_path.parent.mkdir(parents=True, exist_ok=True)
    if not config_path.exists():
        defaults = _jar_default_config(config.PLUGIN_DIR / "floodgate.jar")
        if defaults:
            config_path.write_text(defaults, encoding="utf-8")
    if not config_path.exists():
        return
    data = _load_yaml(config_path)
    data.setdefault("username-prefix", ".")
    _dump_yaml(config_path, data)


def run(force: bool = False) -> dict[str, Any]:
    """Install or update everything the server needs. Safe to call repeatedly."""
    global _CURRENT
    with _LOCK:
        result: dict[str, Any] = {
            "minecraft": config.VERSION,
            "protocol": config.PROTOCOL,
            "crossplay": config.CROSSPLAY,
            "checked_at": time.time(),
            "errors": [],
        }
        if config.EDU_ENABLED:
            installers = (
                ("paper", lambda: ensure_paper(force)),
                ("geyser", lambda: ensure_edu_geyser(force)),
                ("floodgate", lambda: ensure_edu_floodgate(force)),
            )
        else:
            _forget(
                config.PLUGIN_DIR / ".edugeyser-version",
                config.PLUGIN_DIR / ".edufloodgate-version",
            )
            installers = (
                ("paper", lambda: ensure_paper(force)),
                ("geyser", lambda: ensure_plugin("geyser", "Geyser-Spigot.jar", force)),
                ("floodgate", lambda: ensure_plugin("floodgate", "floodgate.jar", force)),
            )
        for name, function in installers:
            try:
                result[name] = function()
            except Exception as exc:  # network hiccups should not brick the Space
                result["errors"].append(f"{name}: {exc}")
                result[name] = {"error": str(exc)}
        try:
            ensure_server_properties()
            ensure_eula()
            ensure_geyser_config()
            ensure_floodgate_config()
            if config.EXTRA_PLUGINS:
                result["plugins"] = ensure_extra_plugins(force)
            if config.EDU_ENABLED:
                result["education"] = {
                    "enabled": True,
                    "connection_id": ensure_edu_connection(),
                }
        except Exception as exc:
            result["errors"].append(f"config: {exc}")
        if not (config.SERVER_DIR / "paper.jar").exists():
            raise RuntimeError("paper.jar is missing; " + "; ".join(result["errors"]))
        _CURRENT = result
        return result


def current() -> dict[str, Any]:
    return _CURRENT
