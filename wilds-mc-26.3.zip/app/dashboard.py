"""Dashboard HTML. Inline CSS/JS so the Space serves one self-contained page."""

PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; padding: 32px 20px 56px;
    font: 15px/1.55 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    background: radial-gradient(1200px 700px at 15% -10%, #1d3b2a 0%, #0b0f0d 55%, #07090a 100%);
    color: #e8efea;
  }
  main { max-width: 940px; margin: 0 auto; display: grid; gap: 18px; }
  header h1 { margin: 0 0 4px; font-size: 30px; letter-spacing: -0.02em; }
  .sub { margin: 0; color: #8fa79a; }
  .card {
    background: rgba(18, 26, 22, 0.82); border: 1px solid rgba(122, 179, 143, 0.18);
    border-radius: 16px; padding: 18px 20px; backdrop-filter: blur(6px);
  }
  .row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
  .chip {
    display: inline-flex; align-items: center; gap: 8px; padding: 5px 12px;
    border-radius: 999px; font-weight: 600; font-size: 13px;
    background: #253429; color: #cfe6d6; border: 1px solid #3a5544;
  }
  .chip::before { content: ""; width: 8px; height: 8px; border-radius: 50%; background: currentColor; }
  .chip.asleep { background: #2a2f38; color: #aab6c4; border-color: #3c4553; }
  .chip.starting { background: #3a3220; color: #f0c674; border-color: #5c4c28; }
  .chip.running { background: #1d3a28; color: #79e29b; border-color: #2f6142; }
  .chip.stopping { background: #3a2620; color: #f09a74; border-color: #5c3a2a; }
  .muted { color: #93a89b; }
  h2 { font-size: 14px; text-transform: uppercase; letter-spacing: 0.1em; color: #8fa79a; margin: 0 0 10px; }
  .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
  button {
    font: inherit; font-weight: 600; padding: 9px 16px; border-radius: 10px; cursor: pointer;
    border: 1px solid #4f8f66; background: #2f6b47; color: #f2fff7;
  }
  button:hover { background: #377f55; }
  button.ghost { background: transparent; border-color: #46564c; color: #d3ded7; }
  button.ghost:hover { background: rgba(255, 255, 255, 0.05); }
  .grid { display: grid; gap: 18px; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }
  ul { margin: 0; padding-left: 18px; }
  li { margin: 4px 0; }
  .events { list-style: none; padding: 0; font-size: 13px; }
  .events li { display: flex; gap: 8px; color: #c2d1c8; }
  .events time { color: #71857a; font-variant-numeric: tabular-nums; }
  pre {
    margin: 0; padding: 12px; border-radius: 10px; overflow: auto; max-height: 260px;
    background: #080c0a; border: 1px solid #1e2a24; color: #a9c9b5;
    font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace;
  }
  .msg { min-height: 20px; color: #f0c674; font-size: 13px; }
  code { background: #0e1512; padding: 2px 6px; border-radius: 6px; border: 1px solid #223029; }
  .foot { color: #6d8077; font-size: 12px; text-align: center; }
</style>
</head>
<body>
<main>
  <header>
    <h1>__TITLE__</h1>
    <p class="sub">Minecraft Java __VERSION__ · Paper · Bedrock + Education via Geyser · sleeps when empty</p>
  </header>

  <section class="card">
    <div class="row">
      <span id="state" class="chip">loading</span>
      <span id="players" class="muted"></span>
    </div>
    <p id="detail" class="muted" style="margin:10px 0 0"></p>
    <div class="actions">
      <button id="wake">Wake server</button>
      <button id="sleep" class="ghost">Save &amp; sleep</button>
    </div>
    <p id="msg" class="msg"></p>
  </section>

  <section class="grid">
    <div class="card">
      <h2>Connect</h2>
      <ul id="connect"><li class="muted">loading…</li></ul>
    </div>
    <div class="card">
      <h2>Recent events</h2>
      <ul id="events" class="events"><li class="muted">loading…</li></ul>
    </div>
  </section>

  <section class="card">
    <h2>Console</h2>
    <pre id="logs">waiting for the control plane…</pre>
  </section>

  <p class="foot">Sleeps __IDLE__ min after the last player leaves · wake on join, Telegram <code>/wake</code>, or the button above · player link <code>/start</code></p>
</main>
<script>
const $ = (id) => document.getElementById(id);
const fmt = (s) => {
  s = Math.max(0, s | 0);
  if (s < 60) return s + "s";
  const m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (m < 60) return m + "m " + (s % 60) + "s";
  return h + "h " + (m % 60) + "m";
};

async function tick() {
  try {
    const res = await fetch("./api/status", { cache: "no-store" });
    const d = await res.json();
    const chip = $("state");
    chip.textContent = d.state;
    chip.className = "chip " + d.state;
    $("players").textContent = d.player_count + " / " + d.max_players + " players";

    let detail = "Java " + d.version + " · " + d.memory + " heap";
    if (d.state === "running") detail += " · up " + fmt(d.uptime_seconds);
    if (d.state === "starting") detail += " · booting " + fmt(d.booting_seconds) + ", ready in ~" + fmt(d.estimated_ready_in);
    if (d.state === "asleep") detail += " · sleeping, 0 cost to idle";
    if (d.players.length) detail += " · " + d.players.join(", ");
    if (d.last_error) detail += " · last error: " + d.last_error;
    $("detail").textContent = detail;

    const connect = [];
    if (d.public_address) connect.push("<li>Java: <code>" + d.public_address + "</code></li>");
    if (d.bedrock_address) connect.push("<li>Bedrock: <code>" + d.bedrock_address + "</code></li>");
    if (d.education && d.education.enabled) {
      if (d.education.connection_id) {
        connect.push("<li>Education Edition: connection ID <code>" + d.education.connection_id +
          "</code> — enter it in the join dialog</li>");
      } else {
        connect.push("<li class='muted'>Education Edition: connection ID is generated on first boot.</li>");
      }
    }
    if (!connect.length) {
      connect.push("<li class='muted'>No public address yet. Java: playit tunnel <b>Minecraft Java</b> -> 127.0.0.1:25565. Bedrock/Education: playit tunnel <b>Minecraft Bedrock (NetherNet)</b>, whose Geyser settings go into <code>plugins/Geyser-Spigot/config.yml</code> (no inbound port). Both are free. Then set <code>MC_PUBLIC_ADDRESS</code>. Host publishing is HTTP(S) only, so this page uses <code>instabox port publish &lt;machine&gt; 7860</code>.</li>");
    }
    connect.push("<li>Dashboard/API: <code>" + location.host + "</code></li>");
    $("connect").innerHTML = connect.join("");

    $("events").innerHTML = (d.events || []).map((e) =>
      "<li><time>" + new Date(e.ts).toLocaleTimeString() + "</time><span>" +
      e.kind + ": " + e.detail + "</span></li>").join("") || "<li class='muted'>nothing yet</li>";

    $("logs").textContent = (d.logs || []).join("\\n") || "(no console output yet)";
  } catch (err) {
    $("state").textContent = "offline";
    $("state").className = "chip asleep";
    $("detail").textContent = "Control plane not reachable: " + err;
  }
}

async function post(path, body) {
  const res = await fetch(path, { method: "POST", headers: body || {} });
  const text = await res.text();
  $("msg").textContent = res.ok ? "OK — " + text : "Failed (" + res.status + "): " + text;
  tick();
}

$("wake").onclick = () => post("./api/wake");
$("sleep").onclick = () => {
  const token = prompt("Admin token (data/admin.token, or the ADMIN_TOKEN secret):");
  if (!token) return;
  post("./api/sleep", { "x-admin-token": token });
};

tick();
setInterval(tick, 3000);
</script>
</body>
</html>
"""


# The only page a player ever sees: one button, the address, nothing else. No
# status internals, no console, no admin actions — pressing it can only wake the
# server, never stop it.
START_PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; display: grid; place-items: center; padding: 24px;
    font: 17px/1.5 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    background: radial-gradient(900px 600px at 50% -10%, #1d3b2a 0%, #0b0f0d 60%, #07090a 100%);
    color: #e8efea;
  }
  main { width: 100%; max-width: 460px; display: grid; gap: 16px; text-align: center; }
  h1 { margin: 0; font-size: 26px; letter-spacing: -0.02em; }
  p { margin: 0; color: #9db3a6; }
  .card {
    background: rgba(18, 26, 22, 0.85); border: 1px solid rgba(122, 179, 143, 0.2);
    border-radius: 18px; padding: 22px; display: grid; gap: 14px;
  }
  button.big {
    font: inherit; font-size: 21px; font-weight: 700; padding: 20px; border-radius: 14px;
    cursor: pointer; border: 1px solid #4f8f66; background: #2f6b47; color: #f2fff7;
  }
  button.big:hover { background: #377f55; }
  button.big:disabled { opacity: 0.55; cursor: default; }
  .addr {
    font: 15px/1.4 ui-monospace, SFMono-Regular, Menlo, monospace; word-break: break-all;
    background: #0e1512; border: 1px solid #223029; border-radius: 10px; padding: 12px;
  }
  .state { font-size: 14px; color: #f0c674; min-height: 20px; }
  .state.ok { color: #79e29b; }
  .hint { font-size: 14px; color: #93a89b; }
  .foot { font-size: 12px; color: #6d8077; }
</style>
</head>
<body>
<main>
  <h1>__TITLE__</h1>
  <p>Minecraft Java __VERSION__</p>
  <section class="card">
    <button id="go" class="big">Start the server</button>
    <div id="state" class="state">checking&hellip;</div>
    <div>
      <div class="hint">Server address &mdash; add this in Minecraft once:</div>
      <div class="addr" id="addr">__ADDRESS__</div>
    </div>
  </section>
  <p class="hint" id="hint">Press the button, wait about a minute, then open Minecraft and click Join.</p>
  <p class="foot">Nothing to install. Pressing it twice is harmless.</p>
</main>
<script>
const $ = (id) => document.getElementById(id);

function render(d) {
  const btn = $("go"), st = $("state");
  if (d.state === "running") {
    st.textContent = "The server is up \u2014 open Minecraft and click Join.";
    st.className = "state ok";
    btn.disabled = true; btn.textContent = "Server is running";
    $("hint").textContent = "You are in. Nothing else to do.";
  } else if (d.state === "starting") {
    st.textContent = "Starting \u2014 about " + Math.max(1, Math.ceil(d.estimated_ready_in || 60)) +
      " seconds left. Keep this page open.";
    st.className = "state";
    btn.disabled = true; btn.textContent = "Starting\u2026";
  } else if (d.state === "stopping") {
    st.textContent = "Saving the world \u2014 press the button again in a few seconds.";
    st.className = "state";
    btn.disabled = true; btn.textContent = "One moment\u2026";
  } else {
    st.textContent = "Asleep. Press the button to start it.";
    st.className = "state";
    btn.disabled = false; btn.textContent = "Start the server";
  }
  if (d.public_address) $("addr").textContent = d.public_address;
}

async function tick() {
  try {
    const res = await fetch("./api/status", { cache: "no-store" });
    render(await res.json());
  } catch (err) {
    $("state").textContent = "Can't reach the server right now \u2014 try again in a minute.";
  }
}

$("go").onclick = async () => {
  $("go").disabled = true;
  $("state").textContent = "Starting\u2026 this takes about a minute.";
  try { await fetch("./api/wake", { method: "POST" }); } catch (err) {}
  setTimeout(tick, 1500);
};

tick();
setInterval(tick, 3000);
</script>
</body>
</html>
"""


def render(title: str, version: str, idle_minutes: float) -> str:
    return (
        PAGE.replace("__TITLE__", title)
        .replace("__VERSION__", version)
        .replace("__IDLE__", f"{idle_minutes:g}")
    )


def render_start(title: str, version: str, address: str) -> str:
    return (
        START_PAGE.replace("__TITLE__", title)
        .replace("__VERSION__", version)
        .replace("__ADDRESS__", address or "ask the owner for the address")
    )
