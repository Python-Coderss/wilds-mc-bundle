"""Dashboard HTML. Inline CSS/JS so the Space serves one self-contained page."""

PAGE = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>__TITLE__</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body {
    margin: 0; min-height: 100vh; padding: 32px 20px 56px;
    font: 15px/1.55 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
    background: radial-gradient(1200px 700px at 15% -10%, #1d3b2a 0%, #0b0f0d 55%, #07090a 100%);
    color: #e8efea;
  }
  main { max-width: 940px; margin: 0 auto; display: grid; gap: 18px; }
  header h1 { margin: 0 0 4px; font-size: 30px; letter-spacing: -0.02em; }
  .sub { margin: 0; color: #8fa79a; }
  .card {
    background: rgba(18, 26, 22, 0.82); border: 1px solid rgba(122, 179, 143, 0.18);
    border-radius: 16px; padding: 18px 20px; backdrop-filter: blur(6px);
  }
  .row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
  .chip {
    display: inline-flex; align-items: center; gap: 8px; padding: 5px 12px;
    border-radius: 999px; font-weight: 600; font-size: 13px;
    background: #253429; color: #cfe6d6; border: 1px solid #3a5544;
  }
  .chip::before { content: ""; width: 8px; height: 8px; border-radius: 50%; background: currentColor; }
  .chip.asleep { background: #2a2f38; color: #aab6c4; border-color: #3c4553; }
  .chip.starting { background: #3a3220; color: #f0c674; border-color: #5c4c28; }
  .chip.running { background: #1d3a28; color: #79e29b; border-color: #2f6142; }
  .chip.stopping { background: #3a2620; color: #f09a74; border-color: #5c3a2a; }
  .muted { color: #93a89b; }
  h2 { font-size: 14px; text-transform: uppercase; letter-spacing: 0.1em; color: #8fa79a; margin: 0 0 10px; }
  .actions { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 14px; }
  button {
    font: inherit; font-weight: 600; padding: 9px 16px; border-radius: 10px; cursor: pointer;
    border: 1px solid #4f8f66; background: #2f6b47; color: #f2fff7;
  }
  button:hover { background: #377f55; }
  button.ghost { background: transparent; border-color: #46564c; color: #d3ded7; }
  button.ghost:hover { background: rgba(255, 255, 255, 0.05); }
  .grid { display: grid; gap: 18px; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }
  ul { margin: 0; padding-left: 18px; }
  li { margin: 4px 0; }
  .events { list-style: none; padding: 0; font-size: 13px; }
  .events li { display: flex; gap: 8px; color: #c2d1c8; }
  .events time { color: #71857a; font-variant-numeric: tabular-nums; }
  pre {
    margin: 0; padding: 12px; border-radius: 10px; overflow: auto; max-height: 260px;
    background: #080c0a; border: 1px solid #1e2a24; color: #a9c9b5;
    font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace;
  }
  .msg { min-height: 20px; color: #f0c674; font-size: 13px; }
  code { background: #0e1512; padding: 2px 6px; border-radius: 6px; border: 1px solid #223029; }
  .foot { color: #6d8077; font-size: 12px; text-align: center; }
</style>
</head>
<body>
<main>
  <header>
    <h1>__TITLE__</h1>
    <p class="sub">Minecraft Java __VERSION__ · Paper · Bedrock + Education via Geyser · sleeps when empty</p>
  </header>

  <section class="card">
    <div class="row">
      <span id="state" class="chip">loading</span>
      <span id="players" class="muted"></span>
    </div>
    <p id="detail" class="muted" style="margin:10px 0 0"></p>
    <div class="actions">
      <button id="wake">Wake server</button>
      <button id="sleep" class="ghost">Save &amp; sleep</button>
    </div>
    <p id="msg" class="msg"></p>
  </section>

  <section class="grid">
    <div class="card">
      <h2>Connect</h2>
      <ul id="connect"><li class="muted">loading…</li></ul>
    </div>
    <div class="card">
      <h2>Recent events</h2>
      <ul id="events" class="events"><li class="muted">loading…</li></ul>
    </div>
  </section>

  <section class="card">
    <h2>Console</h2>
    <pre id="logs">waiting for the control plane…</pre>
  </section>

  <p class="foot">Sleeps __IDLE__ min after the last player leaves · wake on join, Telegram <code>/wake</code>, or the button above</p>
</main>
<script>
const $ = (id) => document.getElementById(id);
const fmt = (s) => {
  s = Math.max(0, s | 0);
  if (s < 60) return s + "s";
  const m = Math.floor(s / 60), h = Math.floor(m / 60);
  if (m < 60) return m + "m " + (s % 60) + "s";
  return h + "h " + (m % 60) + "m";
};

async function tick() {
  try {
    const res = await fetch("./api/status", { cache: "no-store" });
    const d = await res.json();
    const chip = $("state");
    chip.textContent = d.state;
    chip.className = "chip " + d.state;
    $("players").textContent = d.player_count + " / " + d.max_players + " players";

    let detail = "Java " + d.version + " · " + d.memory + " heap";
    if (d.state === "running") detail += " · up " + fmt(d.uptime_seconds);
    if (d.state === "starting") detail += " · booting " + fmt(d.booting_seconds) + ", ready in ~" + fmt(d.estimated_ready_in);
    if (d.state === "asleep") detail += " · sleeping, 0 cost to idle";
    if (d.players.length) detail += " · " + d.players.join(", ");
    if (d.last_error) detail += " · last error: " + d.last_error;
    $("detail").textContent = detail;

    const connect = [];
    if (d.public_address) connect.push("<li>Java: <code>" + d.public_address + "</code></li>");
    if (d.bedrock_address) connect.push("<li>Bedrock: <code>" + d.bedrock_address + "</code></li>");
    if (d.education && d.education.enabled) {
      if (d.education.connection_id) {
        connect.push("<li>Education Edition: connection ID <code>" + d.education.connection_id +
          "</code> — enter it in the join dialog</li>");
      } else {
        connect.push("<li class='muted'>Education Edition: connection ID is generated on first boot.</li>");
      }
    }
    if (!connect.length) {
      connect.push("<li class='muted'>No tunnel yet. Set <code>PLAYIT_SECRET</code> and add a Java TCP 25565 + Bedrock UDP 19132 tunnel in playit.gg.</li>");
    }
    connect.push("<li>Dashboard/API: <code>" + location.host + "</code></li>");
    $("connect").innerHTML = connect.join("");

    $("events").innerHTML = (d.events || []).map((e) =>
      "<li><time>" + new Date(e.ts).toLocaleTimeString() + "</time><span>" +
      e.kind + ": " + e.detail + "</span></li>").join("") || "<li class='muted'>nothing yet</li>";

    $("logs").textContent = (d.logs || []).join("\\n") || "(no console output yet)";
  } catch (err) {
    $("state").textContent = "offline";
    $("state").className = "chip asleep";
    $("detail").textContent = "Control plane not reachable: " + err;
  }
}

async function post(path, body) {
  const res = await fetch(path, { method: "POST", headers: body || {} });
  const text = await res.text();
  $("msg").textContent = res.ok ? "OK — " + text : "Failed (" + res.status + "): " + text;
  tick();
}

$("wake").onclick = () => post("./api/wake");
$("sleep").onclick = () => {
  const token = prompt("Admin token (data/admin.token, or the ADMIN_TOKEN secret):");
  if (!token) return;
  post("./api/sleep", { "x-admin-token": token });
};

tick();
setInterval(tick, 3000);
</script>
</body>
</html>
"""


def render(title: str, version: str, idle_minutes: float) -> str:
    return (
        PAGE.replace("__TITLE__", title)
        .replace("__VERSION__", version)
        .replace("__IDLE__", f"{idle_minutes:g}")
    )
