# Java players: JEI + Xaero's Minimap

This server is **Paper 26.3** ("Wilderness Bound", protocol 777). Java, Bedrock
and Education players share one world; the mods below are Java-side quality of
life and do not affect crossplay.

## The one thing that surprises everyone

**JEI and Xaero's Minimap are client mods.** They are not plugins, they do not
go in `plugins/`, and a jar dropped there is ignored — Paper loads Bukkit
plugins, a mod needs a mod loader (Fabric, NeoForge, Forge).

That is why your JEI test on a vanilla server showed no recipes. Since
**1.21.2** — a change that is still in force in **26.3** — Mojang moved recipe
data to the server and syncs only the recipes a player has *unlocked*.
A vanilla or Paper server never ships the full recipe registry to the client, so
a client-only JEI has nothing to render and falls back to its own bundled
defaults. Nothing was wrong with your install.

So "put it on the server too" is correct for JEI, but on Paper it can only mean
*a plugin that speaks the same channel a mod loader would*. Two such plugins
exist, both covered below.

## What goes where

| Piece | Side | Install location |
| --- | --- | --- |
| JEI | client | `mods/` in a Fabric or NeoForge 26.3 profile |
| Xaero's Minimap (+ World Map) | client | `mods/` in the same profile |
| Client Recipe Fix (JEI/REI) | client | `mods/`, optional, vanilla recipes only |
| `recipe give @a *` | server | built in, `UNLOCK_ALL_RECIPES=true` |
| JEIRecipeFix | server | `plugins/`, sends full recipe data to JEI |
| Server Waypoint / XaeroShare | server | `plugins/`, shared waypoints |

## Client setup (the part every Java player does)

1. Install **Fabric** (or NeoForge) for **26.3**, plus **Fabric API** on Fabric.
2. Drop into `.minecraft/mods/`:
   * **JEI** — the 26.3 build for *your* loader (Fabric build on Fabric, NeoForge
     build on NeoForge). A loader mismatch is the single most common "JEI does
     nothing" cause.
   * **Xaero's Minimap** — and **Xaero's World Map** if you want the full map.
     Both are client-only and work against a plain Paper server unchanged.
   * Optional: **Client Recipe Fix (JEI/REI)** — reconstructs vanilla recipes on
     the client so JEI is useful even with no server plugin at all.
3. Launch the 26.3 profile and join. Recipes appear once the server has sent
   them; the first inventory open can lag a second while JEI indexes.

Use the *fair-play* edition of Xaero's Minimap on any server that cares about
PVP fairness — it disables entity radar and cave mode advantages.

## Server setup (already wired in this repo)

### 1. Unlock every recipe — no plugin needed

`UNLOCK_ALL_RECIPES=true` (the default) makes the supervisor run

```
recipe give @a *      # on ready
recipe give <name> *  # on every join
```

over RCON. This fills the vanilla recipe book and makes the recipes the server
*does* send complete. It costs nothing and cannot break a client.

### 2. Sync the full registry to JEI — one plugin

**JEIRecipeFix** (Paper/Purpur/Folia) sends the recipe data the way a mod loader
would, so JEI and REI list server recipes with no mod loader on the server.

* Upstream states support for **1.21.3 through 26.2** — 26.3 is not claimed yet,
  so treat it as "try it and watch the log". A Paper plugin that reads the
  recipe registry usually survives a minor bump, but a startup exception is
  possible, and a broken plugin in `plugins/` can stop Paper from booting.
* Fabric clients need 1.21.10 or newer; NeoForge clients are fine.
* Install it as an optional plugin (below), boot once, and look for its
  `Recipes synced` line. If Paper fails to start, remove the jar.

### 3. Shared waypoints for Xaero's

Xaero's Minimap is "mostly client-sided; installing it on the server side is
optional for some additional features like world identification". On Paper the
server side is a plugin:

* **Server Waypoint** — server-owned waypoints synced into Xaero's maps (and
  VoxelMap); listed for 26.3, works for players without the client mod via chat
  commands.
* **XaeroShare** — intercepts Xaero's normal waypoint-share chat message and
  opens a Paper Dialog picker so you can send a waypoint to specific players.

Either one, not both.

## Installing optional plugins

`EXTRA_PLUGINS` takes comma- or newline-separated entries, each a bare jar URL
or `name.jar=URL`:

```bash
# Recipe sync for JEI
EXTRA_PLUGINS=https://github.com/Orchiwi/JEIRecipeFix/releases/download/vX.Y.Z/JEIRecipeFix-X.Y.Z.jar

# Waypoint sync + sharing (both, from Modrinth's CDN)
EXTRA_PLUGINS=https://cdn.modrinth.com/data/<project>/versions/<version>/ServerWaypoint.jar,\
https://cdn.modrinth.com/data/<project>/versions/<version>/XaeroShare.jar
```

Downloads are cached by URL: a jar is fetched once, then reused until the URL
changes. A failed download is logged and skipped rather than blocking boot.

On a hosted deployment add the same value to the env file or the host's secrets.

## Do not replace Paper with NeoForge

Running JEI "properly server-side" would mean a NeoForge/Fabric server with the
JEI jar in `mods/`. That would delete Geyser, EduGeyser and Floodgate from the
picture — they are Bukkit plugins — and with them Bedrock and Education
crossplay. The plugin path above gets the same recipes without that trade.

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| JEI shows no recipes at all | client-only JEI on a server that sends none | `UNLOCK_ALL_RECIPES=true`, or JEIRecipeFix, or Client Recipe Fix |
| JEI shows vanilla only, no server recipes | server sends unlocked recipes only | install JEIRecipeFix |
| Log says `JEI is missing recipes` | same, JEI telling you | expected on Paper without the plugin |
| `+` transfer button does nothing | needs server-side JEI on a *modded* server | not available on Paper; craft manually |
| JEI invisible | item list toggled off | `Ctrl+O`, or check the JEI keybind |
| JEI absent from the mods list | loader mismatch | Fabric build on Fabric, NeoForge on NeoForge, both 26.3 |
| Xaero minimap blank underground | cave mode off | Xaero settings → cave mode |
| Xaero waypoints do not sync | no server plugin | install Server Waypoint or XaeroShare |
| Client crashes on join | mod built for another MC version | use the 26.3 build only |

## Verifying on the live server

```bash
curl -s "$SPACE_PUBLIC_URL/api/config" | python3 -m json.tool | grep -E 'unlock|extra_plugins|version'
```

`version` must read `26.3`, `unlock_all_recipes` `true`, and `extra_plugins`
should list the jars you configured. In game, `/recipe` and JEI's recipe list
should agree once the plugin (if installed) has synced.
