#!/usr/bin/env python3
"""Create an UptimeRobot monitor for this Space's /health endpoint.

    UPTIMEROBOT_API_KEY=... SPACE_PUBLIC_URL=https://user-space.hf.space \
        python tools/uptimerobot_setup.py

Add --keyword ok to use a keyword monitor (type 2) instead of a plain HTTP
check (type 1). A five-minute HTTP check is enough to keep a free Space from
being paused for inactivity and to alert you when the control plane dies.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.parse
import urllib.request

API = "https://api.uptimerobot.com/v2/newMonitor"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default=os.environ.get("SPACE_PUBLIC_URL", ""),
                        help="Space URL, e.g. https://user-space.hf.space")
    parser.add_argument("--api-key", default=os.environ.get("UPTIMEROBOT_API_KEY", ""))
    parser.add_argument("--friendly-name", default="Wilds Minecraft Space")
    parser.add_argument("--interval", type=int, default=300, help="seconds; 300 is the free minimum")
    parser.add_argument("--keyword", default="", help="switch to a keyword monitor matching this text")
    parser.add_argument("--alert-contacts", default=os.environ.get("UPTIMEROBOT_ALERT_CONTACTS", ""),
                        help="comma list of alert contact ids, optionally id_threshold")
    args = parser.parse_args()

    if not args.api_key:
        print("error: UPTIMEROBOT_API_KEY (or --api-key) is required", file=sys.stderr)
        return 2
    if not args.url:
        print("error: SPACE_PUBLIC_URL (or --url) is required", file=sys.stderr)
        return 2

    health_url = args.url.rstrip("/") + "/health"
    form = {
        "api_key": args.api_key,
        "format": "json",
        "friendly_name": args.friendly_name,
        "url": health_url,
        "interval": str(args.interval),
        "type": "2" if args.keyword else "1",
    }
    if args.keyword:
        form["keyword_type"] = "1"  # 1 = keyword exists
        form["keyword_value"] = args.keyword
    if args.alert_contacts:
        form["alert_contacts"] = args.alert_contacts

    data = urllib.parse.urlencode(form).encode()
    request = urllib.request.Request(API, data=data, headers={"Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode())
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(json.dumps(payload, indent=2))
    if payload.get("stat") != "ok":
        print("UptimeRobot rejected the monitor; see the message above.", file=sys.stderr)
        return 1
    monitor = payload.get("monitor", {})
    print(f"\nCreated monitor #{monitor.get('id')} → {health_url} every {args.interval}s")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
