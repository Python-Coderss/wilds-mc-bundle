"""Minecraft server supervisor: wake, boot, idle-sleep, shutdown.

The JVM is a child of this process so a Hugging Face Space restart takes the
server down cleanly instead of leaving a half-written world behind.
"""
from __future__ import annotations

import collections
import re
import subprocess
import threading
import time
from typing import Any, Callable

from . import config, provision, rcon, store

# Aikar's flags, tuned for a small G1 heap. Keep them in one place so the
# memory settings can be swapped without touching the spawn logic.
AIKAR_FLAGS = [
    "-XX:+UseG1GC",
    "-XX:+ParallelRefProcEnabled",
    "-XX:MaxGCPauseMillis=200",
    "-XX:+UnlockExperimentalVMOptions",
    "-XX:+DisableExplicitGC",
    "-XX:+AlwaysPreTouch",
    "-XX:G1NewSizePercent=30",
    "-XX:G1MaxNewSizePercent=40",
    "-XX:G1HeapRegionSize=8M",
    "-XX:G1ReservePercent=20",
    "-XX:G1HeapWastePercent=5",
    "-XX:G1MixedGCCountTarget=4",
    "-XX:InitiatingHeapOccupancyPercent=15",
    "-XX:G1MixedGCLiveThresholdPercent=90",
    "-XX:G1RSetUpdatingPauseTimePercent=5",
    "-XX:SurvivorRatio=32",
    "-XX:+PerfDisableSharedMem",
    "-XX:MaxTenuringThreshold=1",
    "-Dusing.aikars.flags=https://mcflags.emc.gs",
    "-Daikars.new.flags=true",
    "-Dterminal.jline=false",
    "-Dterminal.ansi=false",
]

_JOIN_RE = re.compile(r":\s+([A-Za-z0-9_.\-]{1,16})\s+joined the game")
_LEAVE_RE = re.compile(r":\s+([A-Za-z0-9_.\-]{1,16})\s+left the game")
_DONE_RE = re.compile(r"Done \([0-9.]+s\)!")
def run_cap_seconds() -> float:
    """Uptime after which the world is closed ahead of a host's run limit."""
    if config.RUN_CAP_MINUTES <= 0:
        return 0.0
    return max(0.0, (config.RUN_CAP_MINUTES - config.RUN_CAP_MARGIN_MINUTES) * 60)


_LIST_RE = re.compile(r"There are (\d+) of a max(?: of)? (\d+) players online:?\s*(.*)", re.S)


class MinecraftServer:
    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.state = "asleep"  # asleep | starting | running | stopping
        self.proc: subprocess.Popen[str] | None = None
        self.started_at: float | None = None
        self.ready_at: float | None = None
        self.last_reason = "boot"
        self.last_error: str | None = None
        self.players: set[str] = set()
        self.log_tail: collections.deque[str] = collections.deque(maxlen=500)
        self.software: dict[str, Any] = {}
        self._idle_since: float | None = None
        self._notify: Callable[[str], None] | None = None
        self._idle_thread: threading.Thread | None = None
        self._idle_stop = threading.Event()
        self._boot_thread: threading.Thread | None = None

    # ---------------------------------------------------------------- wiring
    def attach_notifier(self, notify: Callable[[str], None]) -> None:
        self._notify = notify

    def _say(self, text: str) -> None:
        self.log_tail.append(f"[space] {text}")
        if self._notify:
            try:
                self._notify(text)
            except Exception:
                pass

    # ---------------------------------------------------------------- status
    def status(self) -> dict[str, Any]:
        with self._lock:
            state = self.state
            players = sorted(self.players)
            ready_at = self.ready_at
            started_at = self.started_at
            booting = int(time.time() - started_at) if started_at and state == "starting" else 0
            return {
                "state": state,
                "players": players,
                "player_count": len(players),
                "uptime_seconds": int(time.time() - ready_at) if ready_at and state == "running" else 0,
                "booting_seconds": booting,
                "estimated_ready_in": max(5, 90 - booting) if state == "starting" else 0,
                "last_reason": self.last_reason,
                "last_error": self.last_error,
                "idle_since": self._idle_since,
                "auto_sleep": config.AUTO_SLEEP,
                "idle_sleep_minutes": config.IDLE_MINUTES,
                "run_cap_minutes": config.RUN_CAP_MINUTES,
                "software": self.software,
                "version": config.VERSION,
                "protocol": config.PROTOCOL,
                "public_port": config.PUBLIC_PORT,
                "server_port": config.SERVER_PORT,
                "bedrock_port": config.BEDROCK_PORT,
                "memory": config.MC_MEMORY,
                "logs": list(self.log_tail)[-40:],
            }

    # ------------------------------------------------------------------ wake
    def wake(self, reason: str = "manual") -> dict[str, Any]:
        with self._lock:
            if self.state in ("starting", "running"):
                return {"started": False, "state": self.state, "reason": self.last_reason}
            if self.state == "stopping":
                return {"started": False, "state": self.state, "reason": self.last_reason}
            self.state = "starting"
            self.started_at = time.time()
            self.ready_at = None
            self.last_reason = reason
            self.last_error = None
            self.software = provision.current()
            store.log_event("wake", f"reason={reason}")
            store.bump("wakes")
            self._say(f"Waking the server ({reason}) — first boot downloads Paper + Geyser, later boots take ~40s.")
            self._boot_thread = threading.Thread(target=self._boot, args=(reason,), daemon=True)
            self._boot_thread.start()
            return {"started": True, "state": self.state, "reason": reason}

    def _boot(self, reason: str) -> None:
        try:
            self.software = provision.run()
        except Exception as exc:
            with self._lock:
                self.last_error = f"provisioning failed: {exc}"
                self.state = "asleep"
                self.started_at = None
            self._say(f"Could not install the server files: {exc}")
            return

        command = [
            "java",
            f"-Xms{config.MC_MIN_MEMORY}",
            f"-Xmx{config.MC_MEMORY}",
            *AIKAR_FLAGS,
            "-jar",
            "paper.jar",
            "nogui",
        ]
        try:
            proc = subprocess.Popen(
                command,
                cwd=str(config.SERVER_DIR),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
            )
        except FileNotFoundError:
            with self._lock:
                self.state = "asleep"
                self.last_error = "java executable not found (the image must ship Java 25+)"
            self._say("Java is missing from the container image.")
            return
        except OSError as exc:
            with self._lock:
                self.state = "asleep"
                self.last_error = f"could not start java: {exc}"
            self._say(f"Could not start Java: {exc}")
            return

        with self._lock:
            self.proc = proc

        deadline = time.time() + config.WAKE_TIMEOUT
        console = open(config.CONSOLE_LOG, "a", encoding="utf-8", errors="replace")
        try:
            console.write(f"\n===== boot {time.strftime('%Y-%m-%d %H:%M:%S')} reason={reason} =====\n")
            console.flush()
            assert proc.stdout is not None
            for line in proc.stdout:
                stripped = line.rstrip("\n")
                self.log_tail.append(stripped)
                console.write(stripped + "\n")
                self._handle_line(stripped)
                if self.state == "starting" and time.time() > deadline and self.ready_at is None:
                    with self._lock:
                        self.last_error = f"server did not finish booting in {config.WAKE_TIMEOUT}s"
                    self._say("Boot timed out; stopping the half-started server.")
                    self._kill()
                    break
        finally:
            try:
                console.close()
            except OSError:
                pass
            code = proc.wait()
            with self._lock:
                stopping = self.state == "stopping"
                was_ready = self.ready_at is not None
                self.proc = None
                self.state = "asleep"
                self.players.clear()
                self.ready_at = None
                self.started_at = None
                self._idle_since = None
                if not stopping and self.last_error is None and was_ready:
                    self.last_error = f"server exited unexpectedly (code {code})"
            store.log_event("server_exit", f"code={code}")
            if not stopping and code not in (0, None):
                self._say(f"Server stopped unexpectedly (exit code {code}).")

    def _unlock_recipes(self, player: str | None = None) -> None:
        """Give a player every recipe the server knows.

        Recipes are server-side since 1.21.2 and only unlocked ones reach the
        client, so without this the in-game recipe book (and anything reading
        it) looks half empty on a fresh join.
        """
        if not config.UNLOCK_ALL_RECIPES:
            return
        try:
            rcon.command(f"recipe give {player or '@a'} *", port=config.RCON_PORT,
                         password=config.RCON_PASSWORD, timeout=5)
        except Exception:
            pass  # RCON may not be up yet on the first lines of boot

    def _handle_line(self, line: str) -> None:
        if _DONE_RE.search(line):
            took = int(time.time() - (self.started_at or time.time()))
            with self._lock:
                if self.ready_at is None:
                    self.ready_at = time.time()
                    self.state = "running"
                    self._idle_since = None
            store.log_event("ready", f"boot_ms={took * 1000}")
            self._say(
                f"Server is up in {took}s. Java {config.VERSION} · Geyser crossplay on "
                f"{config.BEDROCK_PORT}/udp. Sleeping again after {config.IDLE_MINUTES:g} min empty."
            )
            threading.Thread(target=self._unlock_recipes, daemon=True).start()
            return

        match = _JOIN_RE.search(line)
        if match:
            name = match.group(1)
            with self._lock:
                self.players.add(name)
            store.log_event("join", name)
            threading.Thread(target=self._unlock_recipes, args=(name,), daemon=True).start()
            return

        match = _LEAVE_RE.search(line)
        if match:
            name = match.group(1)
            with self._lock:
                self.players.discard(name)
            store.log_event("leave", name)
            return

        lowered = line.lower()
        if "you need to agree to the eula" in lowered:
            with self._lock:
                self.last_error = "eula.txt is not accepted"
            self._say("Paper refused to start: eula.txt is not accepted.")

    # ----------------------------------------------------------------- sleep
    def sleep(self, reason: str = "manual") -> dict[str, Any]:
        with self._lock:
            if self.state not in ("running", "starting"):
                return {"stopped": False, "state": self.state}
            self.state = "stopping"
        store.log_event("sleep", f"reason={reason}")
        store.bump("sleeps")
        self._say(f"Putting the server to sleep ({reason}).")
        thread = threading.Thread(target=self._shutdown, args=(reason,), daemon=True)
        thread.start()
        return {"stopped": True, "state": "stopping"}

    def _shutdown(self, reason: str) -> None:
        proc = self.proc
        if proc is not None:
            try:
                rcon.command("save-all flush", port=config.RCON_PORT,
                             password=config.RCON_PASSWORD, timeout=15)
                rcon.command("stop", port=config.RCON_PORT,
                             password=config.RCON_PASSWORD, timeout=5)
            except Exception:
                pass
            try:
                proc.wait(timeout=90)
            except subprocess.TimeoutExpired:
                self._kill()
        with self._lock:
            self.state = "asleep"
            self.players.clear()
            self.ready_at = None
            self.started_at = None
            self._idle_since = None
        self._say("Server is asleep. The next join or /wake starts it again.")

    def _kill(self) -> None:
        proc = self.proc
        if proc is None:
            return
        try:
            proc.terminate()
            proc.wait(timeout=20)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    # ------------------------------------------------------------ idle watch
    def start_idle_monitor(self) -> None:
        if self._idle_thread and self._idle_thread.is_alive():
            return
        self._idle_thread = threading.Thread(target=self._idle_loop, daemon=True)
        self._idle_thread.start()

    def _idle_loop(self) -> None:
        while not self._idle_stop.wait(15):
            self._check_run_cap()
            if not config.AUTO_SLEEP:
                self._idle_since = None
                continue
            with self._lock:
                if self.state != "running" or self.ready_at is None:
                    self._idle_since = None
                    continue
            count = self._online_count()
            if count > 0:
                self._idle_since = None
                continue
            if self._idle_since is None:
                self._idle_since = time.time()
                store.log_event("idle", "no players online")
                continue
            if time.time() - self._idle_since >= config.IDLE_MINUTES * 60:
                self.sleep(reason="idle")

    def _check_run_cap(self) -> None:
        """Close the world before the host pauses the machine out from under it.

        A pause keeps memory and processes, so a frozen Paper resumes with a huge
        tick gap; stopping the JVM first means the scheduled restart finds a
        saved world instead of a half-written one.
        """
        cap = run_cap_seconds()
        if not cap:
            return
        with self._lock:
            started = self.started_at
            busy = self.state in ("starting", "running")
        if not busy or started is None or time.time() - started < cap:
            return
        self._say(
            f"Host run limit reached ({config.RUN_CAP_MINUTES:g} min, closing "
            f"{config.RUN_CAP_MARGIN_MINUTES:g} min early). Saving the world now."
        )
        store.log_event("run_cap", f"{config.RUN_CAP_MINUTES:g} min")
        self.sleep(reason="host run cap")

    def _online_count(self) -> int:
        try:
            output = rcon.command("list", port=config.RCON_PORT,
                                  password=config.RCON_PASSWORD, timeout=5)
        except Exception:
            with self._lock:
                return len(self.players)
        match = _LIST_RE.search(output or "")
        if match:
            return int(match.group(1))
        return len(self.players)

    def online_players(self) -> tuple[int, int, list[str]]:
        try:
            output = rcon.command("list", port=config.RCON_PORT,
                                  password=config.RCON_PASSWORD, timeout=5)
            return rcon.parse_list(output)
        except Exception:
            with self._lock:
                return len(self.players), config.MAX_PLAYERS, sorted(self.players)

    def shutdown(self) -> None:
        self._idle_stop.set()
        self.sleep(reason="space shutdown")
        proc = self.proc
        if proc is not None:
            try:
                proc.wait(timeout=60)
            except subprocess.TimeoutExpired:
                self._kill()
