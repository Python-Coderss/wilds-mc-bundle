#!/usr/bin/env bash
# Supervisor entrypoint: wake proxy first (so the Minecraft port answers
# immediately), then the HTTP control plane, with the optional playit tunnel.
# Runs in the container (APP_DIR=/app) and natively on a machine.
set -euo pipefail

APP_DIR="${APP_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
export DATA_DIR="${DATA_DIR:-/data}"
mkdir -p "$DATA_DIR/server/plugins" "$DATA_DIR/logs"

PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null 2>&1 || PYTHON=python

echo "[entrypoint] Minecraft ${MC_VERSION:-26.3} · Paper + Geyser + Floodgate"
echo "[entrypoint] app dir: $APP_DIR"
echo "[entrypoint] data dir: $DATA_DIR"
"$PYTHON" -c 'import sys; print("[entrypoint] python " + sys.version.split()[0])'

"$PYTHON" "$APP_DIR/wake_proxy.py" &
PROXY_PID=$!

if [[ -n "${PLAYIT_SECRET:-}" ]] && command -v playit >/dev/null 2>&1; then
  echo "[entrypoint] starting playit tunnel agent"
  ( playit --secret "$PLAYIT_SECRET" >>"$DATA_DIR/logs/playit.log" 2>&1 & )
else
  echo "[entrypoint] playit disabled (no PLAYIT_SECRET or no binary) — set it to expose TCP 25565 / UDP 19132"
fi

shutdown() {
  kill -TERM "$PROXY_PID" 2>/dev/null || true
}
trap shutdown INT TERM

cd "$APP_DIR"
exec "$PYTHON" -m uvicorn app.main:app \
  --host 0.0.0.0 --port "${CONTROL_PORT:-7860}" \
  --proxy-headers --forwarded-allow-ips='*' \
  --log-level info
