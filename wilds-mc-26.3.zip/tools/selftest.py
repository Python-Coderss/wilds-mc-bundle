#!/usr/bin/env python3
"""Offline self-test for the Space. No Docker, no Java, no network.

    python tools/selftest.py

Covers the pieces that break silently: Minecraft packet framing, RCON packet
layout, SQLite storage, config patching, and the HTTP routes (with the JVM
supervisor stubbed out so nothing boots for real).
"""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

_FAILURES: list[str] = []
_CHECKS = 0


def check(name: str, condition: bool, detail: str = "") -> None:
    global _CHECKS
    _CHECKS += 1
    if condition:
        print(f"  ok   {name}")
    else:
        print(f"  FAIL {name} {detail}")
        _FAILURES.append(name)


def section(title: str) -> None:
    print(f"\n{title}")


def main() -> int:
    os.environ.setdefault("TELEGRAM_BOT_TOKEN", "")
    temp = tempfile.mkdtemp(prefix="wilds-selftest-")
    os.environ["DATA_DIR"] = temp
    os.environ["MC_PUBLIC_ADDRESS"] = "tunnel.example:25565"
    # Never let the route test start a real provisioning download.
    os.environ["PROVISION_ON_BOOT"] = "false"

    import wake_proxy
    from app import config, provision, rcon, store

    section("wake proxy: varints and packets")
    for value in (0, 1, 127, 128, 300, 777, 2**21, 2**31 - 1):
        encoded = wake_proxy.encode_varint(value)
        decoded, offset = wake_proxy.decode_varint(encoded, 0)
        check(f"varint {value} round-trips", decoded == value and offset == len(encoded))

    status_packet = wake_proxy.status_bytes("asleep", 60)
    length, offset = wake_proxy.decode_varint(status_packet, 0)
    body = status_packet[offset:]
    check("status frame length matches", length == len(body))
    packet_id, cursor = wake_proxy.decode_varint(body, 0)
    check("status packet id is 0x00", packet_id == 0x00)
    json_len, cursor = wake_proxy.decode_varint(body, cursor)
    payload = json.loads(body[cursor:cursor + json_len].decode())
    check("status advertises protocol 777", payload["version"]["protocol"] == 777)
    check("status advertises 26.3", payload["version"]["name"] == "26.3")
    asleep_motd = json.dumps(payload["description"]).lower()
    check("asleep MOTD says the server is starting", "starting" in asleep_motd)
    check("asleep MOTD tells the player to join again", "join again" in asleep_motd)
    check("status pings stay a valid server-list entry", payload["players"]["max"] == 20)

    kick = wake_proxy.login_kick_bytes()
    kick_len, kick_offset = wake_proxy.decode_varint(kick, 0)
    kick_body = kick[kick_offset:]
    check("kick frame length matches", kick_len == len(kick_body))
    kick_id, kick_cursor = wake_proxy.decode_varint(kick_body, 0)
    check("login disconnect id is 0x00", kick_id == 0x00)
    kick_json_len, kick_cursor = wake_proxy.decode_varint(kick_body, kick_cursor)
    reason = json.loads(kick_body[kick_cursor:kick_cursor + kick_json_len].decode())
    check("kick reason is a JSON text component", isinstance(reason, dict) and "text" in reason)
    check("kick tells a non-technical player to click Join again",
          "join again" in json.dumps(reason).lower())

    section("rcon: packet layout and list parsing")
    packet = rcon.pack(7, rcon.COMMAND, "list")
    (size,) = __import__("struct").unpack("<i", packet[:4])
    check("rcon length prefix is correct", size == len(packet) - 4)
    request_id, packet_type = __import__("struct").unpack("<ii", packet[4:12])
    check("rcon request id/type survive packing", request_id == 7 and packet_type == 2)
    check("rcon body is null terminated", packet.endswith(b"\x00\x00"))
    online, maximum, names = rcon.parse_list("There are 2 of a max of 20 players online: Steve, Alex")
    check("list parsing", (online, maximum, names) == (2, 20, ["Steve", "Alex"]))
    check("empty list parsing", rcon.parse_list("There are 0 of a max of 20 players online: ") == (0, 20, []))

    section("storage: sqlite round-trip")
    store.init()
    store.log_event("test", "hello")
    store.register_chat("123", "tester")
    store.set_kv("owner_chat_id", "123")
    check("event stored", any(e["detail"] == "hello" for e in store.events(5)))
    check("chat stored", store.chats()[0]["chat_id"] == "123")
    check("kv stored", store.get_kv("owner_chat_id") == "123")
    check("counter increments", store.bump("wakes") == 1 and store.bump("wakes") == 2)
    store.init()  # idempotent schema
    check("schema is idempotent", len(store.events(50)) >= 1)

    section("provisioning: server.properties merge")
    provision.ensure_server_properties()
    properties = (config.SERVER_DIR / "server.properties").read_text()
    check("server port is private", f"server-port={config.SERVER_PORT}" in properties)
    check("rcon enabled", "enable-rcon=true" in properties)
    check("secure profile disabled for Geyser", "enforce-secure-profile=false" in properties)

    path = config.SERVER_DIR / "server.properties"
    path.write_text(
        "# operator comment\ndifficulty=hard\ncustom-key=keep-me\nserver-port=1111\n",
        encoding="utf-8",
    )
    provision.ensure_server_properties()
    merged = path.read_text()
    check("operator comment preserved", "# operator comment" in merged)
    check("unknown key preserved", "custom-key=keep-me" in merged)
    check("managed key rewritten", f"server-port={config.SERVER_PORT}" in merged)
    check("non-managed value preserved", "difficulty=hard" in merged)

    provision.ensure_eula()
    check("eula accepted", "eula=true" in (config.SERVER_DIR / "eula.txt").read_text())

    section("provisioning: plugin config patching")
    config_value = """
bedrock:
  port: 19132
  clone-remote-port: true
  motd1: Old
remote:
  address: auto
  port: 25565
  auth-type: online
"""
    jar = config.PLUGIN_DIR / "Geyser-Spigot.jar"
    jar.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(jar, "w") as archive:
        archive.writestr("config.yml", config_value)
    provision.ensure_geyser_config()
    patched = provision._load_yaml(config.PLUGIN_DIR / "Geyser-Spigot" / "config.yml")
    check("geyser bedrock port patched", patched["bedrock"]["port"] == config.BEDROCK_PORT)
    check("geyser clone-remote-port disabled", patched["bedrock"]["clone-remote-port"] is False)
    check("geyser points at private paper port", patched["remote"]["port"] == config.SERVER_PORT)
    check("geyser uses floodgate auth", patched["remote"]["auth-type"] == "floodgate")

    floodgate_jar = config.PLUGIN_DIR / "floodgate.jar"
    with zipfile.ZipFile(floodgate_jar, "w") as archive:
        archive.writestr("config.yml", "username-prefix: .\n")
    provision.ensure_floodgate_config()
    floodgate = provision._load_yaml(config.PLUGIN_DIR / "floodgate" / "config.yml")
    check("floodgate prefix kept", floodgate.get("username-prefix") == ".")

    section("crossplay: Education Edition over NetherNet")
    check("EduGeyser asset URL is pinned", config.EDUGEYSER_URL.endswith("/EduGeyser-Spigot.jar"))
    check("EduFloodgate asset URL is pinned", config.EDUFLOODGATE_URL.endswith("/edufloodgate-spigot.jar"))
    check("crossplay mode is valid", config.CROSSPLAY in {"bedrock", "edu"})

    saved_plugin_dir = config.PLUGIN_DIR
    saved_pin = config.EDU_CONNECTION_ID
    edu_root = Path(temp) / "edu-plugins"
    edu_root.mkdir(parents=True, exist_ok=True)
    config.PLUGIN_DIR = edu_root
    try:
        first_id = provision.edu_connection_id(create=True)
        check("connection id is generated", bool(re.fullmatch(r"\d{10,18}", first_id)))
        check("generated id is 18 digits", len(first_id) == 18)
        edu_file = provision._geyser_config_dir() / "nethernet" / "connection-id.yml"
        check("connection id file is written", edu_file.exists())
        check("connection id is stable across reads", provision.edu_connection_id() == first_id)
        check("geyser dir resolves through nethernet state",
              provision._geyser_config_dir() == edu_file.parent.parent)

        config.EDU_CONNECTION_ID = "1234567890"
        check("pinned id overrides the stored one",
              provision.edu_connection_id(create=True) == "1234567890")
        check("pinned id is persisted", provision.edu_connection_id() == "1234567890")
        config.EDU_CONNECTION_ID = "not-a-number"
        check("invalid pin falls back to the stored id",
              provision.edu_connection_id(create=True) == "1234567890")
        config.EDU_CONNECTION_ID = ""
        check("stored id survives an unpinned read", provision.edu_connection_id() == "1234567890")
    finally:
        config.EDU_CONNECTION_ID = saved_pin
        config.PLUGIN_DIR = saved_plugin_dir

    swap_root = Path(temp) / "swap-plugins"
    swap_root.mkdir(parents=True, exist_ok=True)
    config.PLUGIN_DIR = swap_root
    original_download = provision._download

    def fake_download(url: str, destination: Path, sha256: str | None = None) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(b"jar:" + url.encode())

    provision._download = fake_download
    try:
        (swap_root / ".geyser-build").write_text("257\n", encoding="utf-8")
        (swap_root / "Geyser-Spigot.jar").write_bytes(b"official geyser")
        provision.ensure_edu_geyser()
        check("edu mode downloads the fork over the official jar",
              (swap_root / "Geyser-Spigot.jar").read_bytes().startswith(b"jar:https://codeberg.org"))
        check("edu mode clears the official build stamp",
              not (swap_root / ".geyser-build").exists())
        check("edu geyser is cached on the next boot", provision.ensure_edu_geyser()["cached"] is True)
        check("edu floodgate installs alongside it",
              provision.ensure_edu_floodgate()["source"] == "edufloodgate")
        check("both forks keep the upstream folders Geyser expects",
              (swap_root / "Geyser-Spigot.jar").exists() and (swap_root / "floodgate.jar").exists())
    finally:
        provision._download = original_download
        config.PLUGIN_DIR = saved_plugin_dir

    empty_root = Path(temp) / "edu-empty"
    empty_root.mkdir(parents=True, exist_ok=True)
    config.PLUGIN_DIR = empty_root
    try:
        check("read-only lookup creates nothing", provision.edu_connection_id() == "")
        check("read-only lookup writes no file",
              not (empty_root / "Geyser-Spigot" / "nethernet").exists())
    finally:
        config.PLUGIN_DIR = saved_plugin_dir

    section("telegram: token vs. persistence")
    from app.telegram_bot import TelegramBot

    silent_bot = TelegramBot(server=None, token="", default_chat="")
    check("token gates the bot", silent_bot.enabled is False)
    check("backup refuses without a token", silent_bot.backup() is False)
    check("state.db is available for backup", silent_bot._backup_path() is not None)
    check("backup interval is sane", config.TELEGRAM_BACKUP_HOURS >= 0)

    section("host limits and optional plugins")
    saved_env = os.environ.get("EXTRA_PLUGINS")
    os.environ["EXTRA_PLUGINS"] = (
        "https://example.test/dist/JEIRecipeFix.jar,"
        "ServerWaypoint.jar=https://example.test/sw.jar, nonsense"
    )
    parsed = config._extra_plugins()
    check("bare url keeps its jar name",
          parsed[0] == ("JEIRecipeFix.jar", "https://example.test/dist/JEIRecipeFix.jar"))
    check("name=url form is honoured",
          parsed[1] == ("ServerWaypoint.jar", "https://example.test/sw.jar"))
    check("non-url entries are dropped", len(parsed) == 2)
    if saved_env is None:
        os.environ.pop("EXTRA_PLUGINS", None)
    else:
        os.environ["EXTRA_PLUGINS"] = saved_env

    from app.server import run_cap_seconds

    check("run cap is off by default", run_cap_seconds() == 0)
    saved_cap = (config.RUN_CAP_MINUTES, config.RUN_CAP_MARGIN_MINUTES)
    config.RUN_CAP_MINUTES, config.RUN_CAP_MARGIN_MINUTES = 480, 8
    check("run cap closes the world 8 min early", run_cap_seconds() == 472 * 60)
    config.RUN_CAP_MINUTES, config.RUN_CAP_MARGIN_MINUTES = 10, 20
    check("an oversized margin never goes negative", run_cap_seconds() == 0)
    config.RUN_CAP_MINUTES, config.RUN_CAP_MARGIN_MINUTES = saved_cap
    check("recipes are unlocked by default", config.UNLOCK_ALL_RECIPES is True)

    extra_root = Path(temp) / "extra-plugins"
    extra_root.mkdir(parents=True, exist_ok=True)
    saved_extra_dir = config.PLUGIN_DIR
    saved_extra_list = config.EXTRA_PLUGINS
    config.PLUGIN_DIR = extra_root
    config.EXTRA_PLUGINS = [("ServerWaypoint.jar", "https://example.test/sw.jar")]
    provision._download = fake_download
    try:
        first = provision.ensure_extra_plugins()
        check("extra plugin downloads", first["ServerWaypoint.jar"]["cached"] is False)
        check("extra plugin lands in plugins/", (extra_root / "ServerWaypoint.jar").exists())
        check("extra plugin is cached on the next boot",
              provision.ensure_extra_plugins()["ServerWaypoint.jar"]["cached"] is True)
    finally:
        provision._download = original_download
        config.PLUGIN_DIR = saved_extra_dir
        config.EXTRA_PLUGINS = saved_extra_list

    section("http service: routes")
    try:
        from fastapi.testclient import TestClient
        from app import main as main_module
    except Exception as exc:  # pragma: no cover - environment dependent
        check("fastapi test client available", False, str(exc))
    else:
        main_module.server.wake = lambda reason="selftest": {
            "started": True, "state": "starting", "reason": reason
        }
        main_module.server.sleep = lambda reason="selftest": {"stopped": True, "state": "stopping"}
        with TestClient(main_module.app) as client:
            health = client.get("/health")
            check("/health is 200", health.status_code == 200)
            check("/health reports ok", health.json().get("status") == "ok")
            page = client.get("/")
            check("dashboard renders", page.status_code == 200 and "Wilds" in page.text)
            status = client.get("/api/status")
            check("/api/status returns version", status.json()["version"] == "26.3")
            check("/api/status exposes events", isinstance(status.json()["events"], list))
            check("/api/status reports crossplay mode", status.json()["crossplay"] == config.CROSSPLAY)
            check("/api/status reports education state",
                  status.json()["education"]["enabled"] == config.EDU_ENABLED)
            check("/api/wake accepts joins", client.post("/api/wake").status_code == 200)
            check("/api/sleep needs a token", client.post("/api/sleep").status_code == 401)
            check("/internal/wake rejects non-loopback", client.post("/internal/wake").status_code == 403)
            check(
                "/internal/wake accepts the admin token",
                client.post("/internal/wake", headers={"x-admin-token": config.ADMIN_TOKEN}).status_code == 200,
            )

    section("result")
    if _FAILURES:
        print(f"{len(_FAILURES)} of {_CHECKS} checks failed:")
        for name in _FAILURES:
            print(f"  - {name}")
        return 1
    print(f"all {_CHECKS} checks passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
