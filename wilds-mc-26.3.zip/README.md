---
title: Trust Republic SMP
emoji: ⛏️
colorFrom: green
colorTo: blue
sdk: docker
app_port: 7860
pinned: false
short_description: Java, Bedrock and Education crossplay, sleeps idle
---

# Trust Republic SMP — Minecraft 26.3 server

A Paper **26.3 "Wilderness Bound"** server where **Java, Bedrock and Minecraft
Education** clients share one world, plus a Telegram control bot with SQLite
storage, an HTTP dashboard/health service, and **wake-on-join** so the Space only
spends CPU while someone is actually playing.

Version facts this build is pinned to (checked 2026-11-21):

| Piece | Version | Notes |
| --- | --- | --- |
| Minecraft Java | **26.3** (Wilderness Bound, 2026-09-15) | year.drop.hotfix numbering; no 1.22 exists |
| Protocol | **777** | status + login handled by the wake proxy |
| Java runtime | **25** | required by 26.3 |
| Paper | 26.3 stable (build resolved at boot) | `fill.papermc.io` v3 API, STABLE channel only |
| Bedrock | 26.40–26.65 | what current Geyser builds accept |
| Education Edition | via **NetherNet** (WebRTC) | not RakNet; needs an EduGeyser build |
| Geyser / EduGeyser | EduGeyser **2.28.0-edu** (fork) | supports Java 26.3; one plugin handles Bedrock + Education |
| Floodgate / EduFloodgate | EduFloodgate **2.2.5-edu.13** | the version EduGeyser 2.28 names as required |

## Crossplay: three editions, one world

`CROSSPLAY=edu` (the default here) installs **EduGeyser** instead of upstream
Geyser. EduGeyser is a Geyser fork that speaks NetherNet as well as RakNet, so:

* **Java** players connect to the tunnel address and are authenticated normally.
* **Bedrock** players connect through Geyser's Bedrock listener.
* **Education** players connect with a **connection ID** — a number, not an IP.

The two Geyser variants cannot be installed side by side (same plugin id, same
config folder), so the provisioner swaps them and never runs both. Set
`CROSSPLAY=bedrock` if you want the upstream Geyser build and no Education
support.

### How Education players join

1. The server prints its connection ID on first boot; it is also on the
   dashboard, `/api/status`, and Telegram `/ip`.
2. In Minecraft Education, open the join/connection dialog and enter that number.
3. The ID is stored in `plugins/Geyser-Spigot/nethernet/connection-id.yml` and
   stays the same across restarts. **Do not regenerate it** unless you want to
   hand every player a new number; pin one with `EDU_CONNECTION_ID` (10–18
   digits) if you want it fixed.
4. Optional: join codes (`/edu joincode add` in the console) tie access to a
   Microsoft 365 tenant, and `/edu joincode` re-prints IDs and share links.

Because the client reaches the server through NetherNet signaling and WebRTC,
**Education clients need no forwarded port or UDP tunnel** — the connection ID
is the address. That is why Education is the most Space-friendly path: Hugging
Face proxies only port 7860, and nothing about the EDU join path depends on a
public port. Bedrock (RakNet or NetherNet-by-IP) and Java still do.

## Java mods: JEI + Xaero's Minimap

Both are **client-side** mods and never belong in `plugins/`. The reason JEI
looked empty is server-side: recipe data has been server-owned since 1.21.2, a
change that still applies in **26.3**, and Paper only syncs recipes a player has
unlocked. Full matrix and troubleshooting in
[`docs/JAVA_MODS.md`](docs/JAVA_MODS.md).

Three layers, cheapest first:

1. `UNLOCK_ALL_RECIPES=true` (default) — `recipe give <player> *` on ready and on
every join, so the vanilla recipe book is complete. No plugin, cannot break a
client.
2. `EXTRA_PLUGINS=` — optional Paper plugins: **JEIRecipeFix** pushes the full
recipe registry to JEI, **Server Waypoint** or **XaeroShare** sync Xaero's
waypoints. Comma-separated `name.jar=url` or bare URLs.
3. Client — JEI + Xaero's Minimap (client-only; works against plain Paper).

Do not swap Paper for NeoForge to run JEI server-side: Geyser, EduGeyser and
Floodgate are Bukkit plugins, so crossplay would go with them.

## How it works

```
player ──TCP──▶ wake proxy :25565 ──▶ Paper :25566  (only while awake)
                    │
                    ├─ status ping  → real MOTD: "asleep, waking…"
                    ├─ join attempt → POST /internal/wake → kick "reconnect in ~75s"
                    └─ server awake → raw TCP pipe

Bedrock / Education ──▶ EduGeyser (inside Paper) :19132 + NetherNet
Education join path  ──▶ connection ID → WebRTC, no inbound port needed

HTTP :7860 ─ dashboard · /health (UptimeRobot) · /api/status · /api/wake
Telegram ──▶ long polling ──▶ same control plane ──▶ SQLite (/data/state.db)
```

* **Sleeping** — after `IDLE_SLEEP_MINUTES` (default 10) with no players, the
  supervisor runs `save-all flush`, then `stop`, and the JVM exits.
* **Waking** — the first status ping or Java join attempt starts Paper. The
  player is kicked with a readable message (the "temp lobby") and reconnects when
  it is up. Telegram `/wake` and the dashboard button do the same.
* **No double-spend** — the HTTP service stays up while Minecraft sleeps, so
  `/health` and Telegram keep working for cents instead of a full server.

## Deploy

Docker Spaces need a paid Hugging Face plan (PRO or Team). Then:

```bash
hf auth login                      # one-time, opens a browser
hf repos create <user>/wilds-mc --type space --space-sdk docker --flavor cpu-basic --private
hf upload <user>/wilds-mc . --repo-type space --exclude "**/__pycache__/**" --exclude ".venv/**"
```

### InstaBox (free 8 GiB, no card, no Docker)

InstaBox's free plan is the only host found that gives 4 vCPU / 8 GiB RAM, a
20 GiB persistent disk and no card, with no credit or ad grind. The server runs
straight on the VM: `/opt/wilds` (code), `/opt/jdk-25` (Temurin 25 beside the
image's Java 21), `/data` (world, plugins, logs).

Two files, one command:

| File | What it is |
| --- | --- |
| `dist/wilds-mc-26.3.zip` | the server bundle (`python3 tools/build_bundle.py`) |
| `install.sh` | installs, supervises and controls it (`restart`, `stop`, `status`) |

```bash
# copy dist/wilds-mc-26.3.zip to the machine (drag it onto the desktop),
# then in that folder the only command you need:
sudo bash install.sh wilds-mc-26.3.zip
```

That installs Java 25, a venv, the playit agent, `.env`, the boot hook and starts
the control plane. Then `sudo nano /opt/wilds/.env` for `PLAYIT_SECRET` and
`sudo bash /opt/wilds/install.sh restart`.

Two host limits shape the setup: 480 minutes per run (the world saves 8 minutes
early via `RUN_CAP_MINUTES=470`, then the 16:55 restart resets the counter) and a
30-minute idle pause, so the machine is only up inside the 09:00–19:00 UTC window
scheduled by `.github/workflows/instabox-window.yml`.

#### Auto start for players

Three things can be asleep, and only one of them can be woken by a player:

| Asleep | What is still listening | What wakes it | Setting |
| --- | --- | --- | --- |
| Paper (the JVM) | the wake proxy on 25565 — it answers with "waking, reconnect in ~75s" | the first Java login attempt or status ping | `AUTO_SLEEP=true`, `IDLE_SLEEP_MINUTES=10` |
| The VM | nothing at all, no port, no tunnel | only an InstaBox API `start`: the window cron, `workflow_dispatch`, or Telegram `/wake` | `.github/workflows/instabox-window.yml` |
| The playit tunnel | the agent is not dialling out | nothing — the agent must run on the VM | `PLAYIT_SECRET` |

So player-triggered start needs all three: the VM up, the tunnel dialling, and
`AUTO_SLEEP=true` so Paper is allowed to sleep in the first place. Then a join
goes: connect → proxy says "waking" → `save-all`-safe boot → reconnect in ~40 s.

```bash
sudo sed -i 's/^AUTO_SLEEP=.*/AUTO_SLEEP=true/' /opt/wilds/.env
sudo bash /opt/wilds/install.sh restart
```

**What players actually do** — no mods, no config, no commands:

1. Multiplayer → Add Server → paste the address once, e.g.
   `something.playit.gg:25565`.
2. Click Join. If the world is asleep they are kicked with "starting it now —
   click Join again in about 75s". Nothing else to type.
3. Click Join again. They are in.

Send them that address and those three lines; everything else is server-side.
Java clients also need no mods to play — JEI and Xaero's are optional.

**The player link.** `/start` is a page with one big button and the address, and
nothing else — no console, no admin actions, no jargon:

```bash
instabox port publish <machine> 7860     # once, gives a stable URL
# hand players:  https://<that-url>/start
```

Press → it wakes the world and counts down ("about 60 seconds left") → flips to
"The server is up — open Minecraft and click Join." Pressing it twice is
harmless; it can only wake, never stop. The page is served by the control plane,
so it answers whenever the VM is up and not at all while InstaBox has the VM
paused — the window cron is still what covers the other hours.

Caveats worth knowing:

* **Bedrock and Education cannot wake it.** Geyser runs inside Paper, so while the
  JVM sleeps nothing answers on 19132 or NetherNet. Java only.
* **A stopped VM cannot hear a join.** Nothing is listening, so no packet can
  trigger a start; the window cron is the only zero-cost option. To cover more
  hours, add start entries to the workflow's `schedule` — each one resets the
  run counter, and the free plan allows 3 starts per minute.
* **InstaBox pauses an idle VM after 30 minutes**, playing or not, which is why
  the window is built around activity rather than an always-on daemon.

### Variables and secrets

Set these in *Settings → Variables and secrets*.

| Name | Needed | Purpose |
| --- | --- | --- |
| `PLAYIT_SECRET` | for Java/Bedrock | agent secret from playit.gg; tunnels **Minecraft Java** → 25565 and **Minecraft Bedrock (NetherNet)** (settings pasted into Geyser) |
| `CROSSPLAY` | no | `edu` (default) = EduGeyser + EduFloodgate; `bedrock` = upstream Geyser |
| `EDU_CONNECTION_ID` | no | pin the Education connection ID (10–18 digits) instead of auto-generating |
| `EDUGEYSER_VERSION` / `EDUFLOODGATE_VERSION` | no | override the pinned fork tags |
| `TELEGRAM_BOT_TOKEN` | optional | BotFather token — **this is the key that enables the bot** |
| `TELEGRAM_CHAT_ID` | optional | lock the bot to one chat (otherwise the first `/start` claims it) |
| `TELEGRAM_BACKUP_HOURS` | optional | every N hours, send `state.db` to the owner chat (default `12` when a token is set, `0` disables) |
| `MC_PUBLIC_ADDRESS` | optional | `your-tunnel.playit.gg:25565`, shown in `/ip` and the dashboard |
| `BEDROCK_PUBLIC_ADDRESS` | optional | Bedrock tunnel address |
| `UPTIMEROBOT_HEARTBEAT_URL` | optional | push monitor pinged on wake/ready |
| `UPTIMEROBOT_API_KEY` | optional | used by `tools/uptimerobot_setup.py` |
| `SPACE_PUBLIC_URL` | optional | `https://<user>-<space>.hf.space` for links |
| `ADMIN_TOKEN` | optional | protects `/api/sleep`; generated into `/data/admin.token` if unset |
| `RCON_PASSWORD` | optional | generated into `/data/rcon.pass` if unset |
| `MC_MEMORY` / `MC_MIN_MEMORY` | optional | JVM heap, default `4G` / `1G` |
| `IDLE_SLEEP_MINUTES` | optional | default `10`; `AUTO_SLEEP=false` disables sleeping |
| `SERVER_NAME` | `Trust Republic SMP` | what players see: MOTD, `/start` page, dashboard |
| `MC_MOTD` | optional | overrides just the server-list line |
| `UNLOCK_ALL_RECIPES` | optional | default `true`; grants every recipe on ready and on join |
| `EXTRA_PLUGINS` | optional | extra Paper plugins, `name.jar=url` or bare URLs, comma separated |
| `RUN_CAP_MINUTES` | for InstaBox | host run limit; the world is closed early at this mark (`0` = off) |
| `RUN_CAP_MARGIN_MINUTES` | optional | how long before the cap to stop the world, default `8` |
| `WAKE_ON_BOOT` | for InstaBox | start Paper as soon as the control plane is up |

### Telegram: the token is a key, not the storage

Worth being blunt, because the two get conflated:

* `TELEGRAM_BOT_TOKEN` is **authentication** — without it the bot is disabled and
  logs `disabled: no TELEGRAM_BOT_TOKEN`. It stores nothing.
* The bot's data (owner chat, counters, event log) is a SQLite file at
  `DATA_DIR/state.db`, which lives inside the container.
* **`/data` is wiped when a Space restarts.** A restart therefore forgets the
  owner chat and counters *unless* you either mount a bucket or rely on the chat
  itself.

Two ways to make it durable:

```bash
# 1. Real persistence for world + plugins + state.db
hf buckets create <user>/wilds-data
hf spaces volumes set <user>/wilds-mc -v hf://buckets/<user>/wilds-data:/data
```

2. Telegram as an off-site copy of the small stuff: `/backup` sends `state.db`
   to the owner chat on demand, and `TELEGRAM_BACKUP_HOURS` (default 12 once a
   token exists) does it automatically. The world itself is too large for the
   Bot API, so it still needs the bucket.

### Public connectivity (Java and Bedrock)

Hugging Face only proxies the HTTP port. [playit.gg](https://playit.gg) is
bundled for the game ports:

1. Create an agent secret at playit.gg and set `PLAYIT_SECRET`.
2. Add a tunnel of type **Minecraft Java**, local address `127.0.0.1` port
   `25565` — that is the wake proxy, not Paper, so it keeps working while the
   world sleeps. Put its public address in `MC_PUBLIC_ADDRESS`.
3. Add a second tunnel of type **Minecraft Bedrock (NetherNet)** and tick the
   experimental box. This one is *not* a UDP port forward: open the tunnel →
   **Configuration help** → **Geyser** tab → **Copy**, then paste those keys into
   `/data/server/plugins/Geyser-Spigot/config.yml` under `bedrock:` (keep
   `port: 19132` and `address: 0.0.0.0`). Put the tunnel address in
   `BEDROCK_PUBLIC_ADDRESS`. On the next boot the console should print
   `Registered with the external signaling service`.

#### Why a tunnel at all, when the host publishes ports?

Because InstaBox publishes **HTTP(S)** ports, not game ports. Its `port publish`
gives an HTTPS URL to a web server; `--tcp` (raw TCP) is **paid plans only** and
is a TLS/SNI address, which a Minecraft client cannot speak; UDP is not offered.
So:

| Need | Mechanism | Cost |
| --- | --- | --- |
| `/start` page, API, dashboard (7860) | `instabox port publish <machine> 7860` | free |
| Java 25565 (TCP) | playit **Minecraft Java** preset | free tier |
| Bedrock + Education | playit **Minecraft Bedrock (NetherNet)** tunnel; its settings go into Geyser's config, so there is no inbound port | free tier, experimental |

`sudo bash /opt/wilds/install.sh ports` prints exactly this plan. The tunnel is
not redundant here: it is the only free path for the game protocol, and it also
keeps the VM's own ports closed. (For your own debugging, `instabox port-forward`
is SSH-only and not usable by players.)

#### What playit's free tier actually covers

Free is **not** UDP-only, but it is **preset-only**. The free plan lists
Minecraft Java, both Bedrock presets, MC Simple Voice Chat, the other named games
and plain UDP. Premium ($3/month) is what adds *generic* TCP, TCP+UDP, SSH and
HTTPS, regional routing and extra ports.

So this server works on free, provided the Java tunnel is the **Minecraft Java**
preset rather than "custom TCP": that preset is a TCP proxy pointed at 25565,
which is exactly the wake proxy, so it keeps working while Paper sleeps.

* The `/start` page cannot go through playit on free — HTTPS tunnels are
  Premium. Publish the control plane port on the host instead:
  `instabox port publish <machine> 7860`.
* If you ever need a non-Minecraft TCP port, free playit will not do it; publish
  the port on the host (that is what InstaBox is already doing for 7860) or use
  another free TCP tunnel.
* Free tunnels use global anycast, so players can be routed through a distant
  datacenter. Choosing a region is Premium.

Caveat worth checking with real clients: from Bedrock **26.60** (October 2026)
NetherNet is the default transport and RakNet is deprecated, so the old
"Minecraft Bedrock" (RakNet) tunnel type no longer covers modern clients — use
the NetherNet type, which carries a private token instead of forwarding a port.
The pasted keys survive boot because the provisioner only rewrites its own
managed keys (`port`, `clone-remote-port`, `motd1`, `server-name`, `remote.*`).
Education players use the connection ID and are unaffected. **Not verified:**
whether this EduGeyser/EduFloodgate fork implements the NetherNet signaling
client that the NetherNet tunnel expects — check for
`Registered with the external signaling service` in the log.

### UptimeRobot

`/health` returns HTTP 200 with `{"status":"ok",...}` and never blocks on
Minecraft, which makes it the right monitor target:

```bash
UPTIMEROBOT_API_KEY=... SPACE_PUBLIC_URL=https://<user>-<space>.hf.space \
  python tools/uptimerobot_setup.py --keyword ok
```

Five-minute HTTP checks also keep a free Space from being paused for inactivity.

## Honest limits

* **Bedrock and Education players cannot wake a sleeping server.** Geyser runs
  inside Paper, so while the JVM sleeps nothing answers on 19132 or NetherNet.
  Java joins, status pings, the dashboard, and Telegram `/wake` all wake it;
  everyone else sees "unable to connect" until then. A standalone EduGeyser
  process would fix this at the cost of a second JVM and a second wake path.
* **The "temp lobby" is protocol-level, not a world.** It is a real server-list
  entry plus a login-screen message; there is no second playable dimension.
* **Education is a fork, not upstream.** EduGeyser lags Geyser slightly; when
  26.4 lands, bump `EDUGEYSER_VERSION`/`EDUFLOODGATE_VERSION` together or you get
  a login mismatch. Its connection-ID identity file must not be deleted casually.
* **First boot is slow** (Paper ~50 MB + EduGeyser ~54 MB + EduFloodgate ~12 MB),
  expect a couple of minutes; later wakes are ~40–90s.
* **One Space, one server.** A Paper world does not scale across replicas.

## Local development

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install fastapi uvicorn httpx PyYAML
DATA_DIR=./data python -m uvicorn app.main:app --port 7860
python tools/selftest.py           # offline checks, no Docker needed
```

Paper needs Java 25; the container has it, a local JDK 8 will not run 26.3.

## Layout

```
app/config.py       env, persisted secrets, crossplay mode
app/server.py       JVM supervisor: wake, boot, idle-sleep, shutdown
app/provision.py    Paper/EduGeyser/EduFloodgate download, config + NetherNet ID
app/rcon.py         minimal RCON client (list, save-all, stop)
app/store.py        SQLite: events, chats, counters
app/telegram_bot.py long-polling bot, notifications, state.db backups
app/main.py         FastAPI routes (/health, /api/*)
app/dashboard.py    single-page dashboard
wake_proxy.py       protocol-777 wake-on-join proxy / temp lobby
scripts/entrypoint.sh
tools/uptimerobot_setup.py
tools/selftest.py
docs/JAVA_MODS.md   JEI + Xaero's install and recipe-sync troubleshooting
.github/workflows/instabox-window.yml   scheduled 10 h/day window
install.sh          one-file installer + controller for a bare machine
tools/build_bundle.py   builds dist/wilds-mc-26.3.zip
```
