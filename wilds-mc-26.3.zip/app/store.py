"""Durable storage for the Space.

Everything the Telegram bot needs (allowed chats, counters, a tail of server
events) lives in one SQLite file inside DATA_DIR. SQLite keeps the Space free
of extra services while still giving the bot real storage rather than
in-memory state that dies with the container.
"""
from __future__ import annotations

import datetime as _dt
import json
import sqlite3
import threading
from typing import Any

from . import config

_SCHEMA = """
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    kind TEXT NOT NULL,
    detail TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chats (
    chat_id TEXT PRIMARY KEY,
    username TEXT,
    added_at TEXT NOT NULL,
    last_seen TEXT
);
CREATE TABLE IF NOT EXISTS kv (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

# Reentrant: bump() holds the lock while calling get_kv()/set_kv().
_LOCK = threading.RLock()


def _now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def _connect() -> sqlite3.Connection:
    connection = sqlite3.connect(config.DB_PATH, timeout=30)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA busy_timeout=10000")
    return connection


def init() -> None:
    with _LOCK, _connect() as connection:
        connection.executescript(_SCHEMA)


def log_event(kind: str, detail: str) -> None:
    try:
        with _LOCK, _connect() as connection:
            connection.execute(
                "INSERT INTO events (ts, kind, detail) VALUES (?, ?, ?)",
                (_now(), kind, detail),
            )
    except sqlite3.Error:
        pass


def events(limit: int = 20) -> list[dict[str, Any]]:
    try:
        with _connect() as connection:
            rows = connection.execute(
                "SELECT ts, kind, detail FROM events ORDER BY id DESC LIMIT ?",
                (max(1, min(limit, 200)),),
            ).fetchall()
        return [dict(row) for row in rows]
    except sqlite3.Error:
        return []


def register_chat(chat_id: str, username: str = "") -> None:
    try:
        with _LOCK, _connect() as connection:
            connection.execute(
                "INSERT INTO chats (chat_id, username, added_at, last_seen) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(chat_id) DO UPDATE SET last_seen=excluded.last_seen, "
                "username=COALESCE(NULLIF(excluded.username, ''), chats.username)",
                (str(chat_id), username, _now(), _now()),
            )
    except sqlite3.Error:
        pass


def chats() -> list[dict[str, Any]]:
    try:
        with _connect() as connection:
            rows = connection.execute(
                "SELECT chat_id, username, added_at, last_seen FROM chats ORDER BY added_at"
            ).fetchall()
        return [dict(row) for row in rows]
    except sqlite3.Error:
        return []


def get_kv(key: str, default: str = "") -> str:
    try:
        with _connect() as connection:
            row = connection.execute("SELECT value FROM kv WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else default
    except sqlite3.Error:
        return default


def set_kv(key: str, value: str) -> None:
    try:
        with _LOCK, _connect() as connection:
            connection.execute(
                "INSERT INTO kv (key, value) VALUES (?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, value),
            )
    except sqlite3.Error:
        pass


def bump(key: str, amount: int = 1) -> int:
    """Increment an integer counter stored in kv and return the new value."""
    with _LOCK:
        current = int(get_kv(key, "0") or 0) + amount
        set_kv(key, str(current))
    return current


def counters() -> dict[str, int]:
    result: dict[str, int] = {}
    for key in ("wakes", "sleeps", "telegram_commands"):
        try:
            result[key] = int(get_kv(key, "0") or 0)
        except ValueError:
            result[key] = 0
    return result


def snapshot() -> str:
    """Small JSON dump, handy for debugging from the dashboard."""
    return json.dumps({"counters": counters(), "chats": chats(), "events": events(10)})
