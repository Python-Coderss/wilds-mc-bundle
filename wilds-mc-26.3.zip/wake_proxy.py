#!/usr/bin/env python3
"""Wake proxy: the "temp lobby" in front of a sleeping Minecraft server.

Why this exists
---------------
A Hugging Face Space bills CPU while the container runs, so the Minecraft
server is stopped when nobody is online. Something must still hold the public
TCP port and answer the client, otherwise the first player of the day only
sees a timeout. This proxy does that:

  * It speaks just enough of the Minecraft protocol for protocol 777 / 26.3.
  * A status ping gets a real server-list entry: "server is asleep, waking…".
  * A login attempt starts the server and is kicked with a clear message
    instead of a generic connection error.
  * Once Paper is up, the socket is piped byte-for-byte to 127.0.0.1:25566.

It is not a second playable world: a real lobby server would double the RAM
and defeat the point of sleeping. Players reconnect ~40-90s later.
"""
from __future__ import annotations

import asyncio
import contextlib
import json
import os
import sys
import time
import traceback
import urllib.request

PUBLIC_PORT = int(os.environ.get("PUBLIC_PORT", "25565"))
SERVER_PORT = int(os.environ.get("SERVER_PORT", "25566"))
CONTROL_PORT = int(os.environ.get("CONTROL_PORT", "7860"))
MC_VERSION = os.environ.get("MC_VERSION", "26.3")
PROTOCOL = int(os.environ.get("MC_PROTOCOL", "777"))
MAX_PLAYERS = int(os.environ.get("MAX_PLAYERS", "20"))
MOTD = os.environ.get("MC_MOTD", f"Minecraft {MC_VERSION} - Wilderness Bound")
TEMP_LOBBY_MINUTES = os.environ.get("WAKE_MESSAGE_SECONDS", "75")

CONTROL = f"http://127.0.0.1:{CONTROL_PORT}"

WAKE_MOTD = {
    "text": "☕ Server is asleep — waking up",
    "color": "gold",
    "extra": [
        {"text": "\nYou just started it. Reconnect in about " + TEMP_LOBBY_MINUTES + "s.", "color": "gray"}
    ],
}
ASLEEP_KICK = {
    "text": "☕ The server was asleep — it is waking up now.\n",
    "color": "gold",
    "extra": [
        {"text": "Please reconnect in about " + TEMP_LOBBY_MINUTES + " seconds.", "color": "gray"}
    ],
}


def log(message: str) -> None:
    print(f"[wake-proxy] {time.strftime('%H:%M:%S')} {message}", flush=True)


# --------------------------------------------------------------------- varint
def encode_varint(value: int) -> bytes:
    out = bytearray()
    while True:
        byte = value & 0x7F
        value >>= 7
        if value:
            out.append(byte | 0x80)
        else:
            out.append(byte)
            return bytes(out)


def decode_varint(data: bytes, offset: int = 0) -> tuple[int, int]:
    num = 0
    shift = 0
    while True:
        if offset >= len(data) or shift > 35:
            raise ValueError("malformed varint")
        byte = data[offset]
        offset += 1
        num |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return num, offset
        shift += 7


async def read_varint(reader: asyncio.StreamReader, first: int | None = None) -> int:
    num = 0
    shift = 0
    if first is not None:
        num = first & 0x7F
        if not first & 0x80:
            return num
        shift = 7
    while shift <= 35:
        raw = await reader.readexactly(1)
        byte = raw[0]
        num |= (byte & 0x7F) << shift
        if not byte & 0x80:
            return num
        shift += 7
    raise ValueError("varint too long")


def mc_string(value: str) -> bytes:
    raw = value.encode("utf-8")
    return encode_varint(len(raw)) + raw


def frame(packet_id: int, payload: bytes = b"") -> bytes:
    body = encode_varint(packet_id) + payload
    return encode_varint(len(body)) + body


# ------------------------------------------------------------------ control API
def _control_json(path: str, timeout: float = 2.0) -> dict:
    try:
        with urllib.request.urlopen(CONTROL + path, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception:
        return {}


def trigger_wake() -> None:
    try:
        request = urllib.request.Request(CONTROL + "/internal/wake", data=b"", method="POST")
        urllib.request.urlopen(request, timeout=3).close()
    except Exception as exc:
        log(f"wake request failed: {exc}")


# ------------------------------------------------------------------- responses
def status_bytes(state: str, ready_in: int) -> bytes:
    if state == "running":
        description = {"text": MOTD, "color": "green"}
    elif state == "starting":
        description = {
            "text": f"☕ Starting up — ready in ~{ready_in}s",
            "color": "gold",
            "extra": [{"text": "\n" + MOTD, "color": "gray"}],
        }
    elif state == "stopping":
        description = {"text": "💤 Saving the world — back in a moment", "color": "gold"}
    else:
        description = dict(WAKE_MOTD)

    payload = {
        "version": {"name": MC_VERSION, "protocol": PROTOCOL},
        "players": {
            "max": MAX_PLAYERS,
            "online": 0,
            "sample": [
                {"name": "Wake-on-join", "id": "00000000-0000-0000-0000-000000000001"},
                {"name": f"/wake in Telegram", "id": "00000000-0000-0000-0000-000000000002"},
            ],
        },
        "description": description,
        "enforcesSecureChat": False,
    }
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    return frame(0x00, encode_varint(len(raw)) + raw)


def login_kick_bytes() -> bytes:
    """Login Disconnect (0x00) — reason is a JSON text component on 26.3."""
    raw = json.dumps(ASLEEP_KICK, ensure_ascii=False).encode("utf-8")
    return frame(0x00, encode_varint(len(raw)) + raw)


# --------------------------------------------------------------------- piping
async def pipe(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    try:
        while True:
            chunk = await reader.read(65536)
            if not chunk:
                break
            writer.write(chunk)
            await writer.drain()
    except (ConnectionError, asyncio.IncompleteReadError, OSError):
        pass
    finally:
        with contextlib.suppress(Exception):
            writer.close()


async def forward_to_server(initial: bytes, client_reader: asyncio.StreamReader,
                            client_writer: asyncio.StreamWriter) -> bool:
    try:
        upstream_reader, upstream_writer = await asyncio.wait_for(
            asyncio.open_connection("127.0.0.1", SERVER_PORT), timeout=2.5
        )
    except Exception:
        return False
    try:
        upstream_writer.write(initial)
        await upstream_writer.drain()
        await asyncio.gather(
            pipe(client_reader, upstream_writer),
            pipe(upstream_reader, client_writer),
        )
    finally:
        with contextlib.suppress(Exception):
            upstream_writer.close()
    return True


# ---------------------------------------------------------------- connection
async def handle(reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
    peer = writer.get_extra_info("peername")
    try:
        first = (await asyncio.wait_for(reader.readexactly(1), timeout=10))[0]
        if first == 0xFE:  # legacy pre-1.7 ping
            return
        length = await asyncio.wait_for(read_varint(reader, first), timeout=10)
        if length <= 0 or length > 1 << 16:
            return
        raw_body = await asyncio.wait_for(reader.readexactly(length), timeout=10)
        initial = encode_varint(length) + raw_body

        packet_id, offset = decode_varint(raw_body, 0)
        if packet_id != 0x00:
            return
        _, offset = decode_varint(raw_body, offset)          # protocol version
        host_len, offset = decode_varint(raw_body, offset)   # server address
        offset += host_len
        offset += 2                                          # port
        next_state, offset = decode_varint(raw_body, offset)

        if next_state == 1:  # status
            status = await asyncio.to_thread(_control_json, "/api/status")
            state = status.get("state", "asleep")
            ready_in = int(status.get("estimated_ready_in") or 75)
            if state != "running":
                asyncio.create_task(asyncio.to_thread(trigger_wake))
            log(f"status ping from {peer} (state={state})")
            writer.write(status_bytes(state, ready_in))
            await writer.drain()
            # ping/pong: echo the client's ping frame verbatim
            try:
                ping_len = await asyncio.wait_for(read_varint(reader), timeout=5)
                ping_body = await asyncio.wait_for(reader.readexactly(ping_len), timeout=5)
                writer.write(encode_varint(ping_len) + ping_body)
                await writer.drain()
            except (asyncio.TimeoutError, asyncio.IncompleteReadError, ConnectionError):
                pass
            return

        if next_state == 2:  # login
            status = await asyncio.to_thread(_control_json, "/api/status")
            if status.get("state") == "running":
                if await forward_to_server(initial, reader, writer):
                    return
            log(f"join attempt from {peer} while {status.get('state', 'asleep')} — waking")
            asyncio.create_task(asyncio.to_thread(trigger_wake))
            writer.write(login_kick_bytes())
            await writer.drain()
            return
    except (asyncio.TimeoutError, asyncio.IncompleteReadError, ValueError, ConnectionError):
        pass
    except Exception:
        log("unexpected error:\n" + traceback.format_exc())
    finally:
        with contextlib.suppress(Exception):
            writer.close()


async def main() -> None:
    server = await asyncio.start_server(handle, "0.0.0.0", PUBLIC_PORT)
    log(f"listening on :{PUBLIC_PORT} → Paper :{SERVER_PORT} · Minecraft {MC_VERSION} (protocol {PROTOCOL})")
    log("status pings and join attempts both wake the server")
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
