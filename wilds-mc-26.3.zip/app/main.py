"""HTTP service: dashboard, status API, health check, and wake/sleep control.

This is the "second service" on the Space's only public port (7860). It is also
what UptimeRobot polls every five minutes, which keeps a free Space from being
paused for inactivity without waking the Minecraft server.
"""
from __future__ import annotations

import threading
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse

from . import config, dashboard, provision, store
from .server import MinecraftServer
from .telegram_bot import TelegramBot

server = MinecraftServer()
bot = TelegramBot(server)


def _prefetch() -> None:
    """Warm the downloads in the background so the first join is not slow."""
    try:
        provision.run()
        store.log_event("provision", "server files ready")
    except Exception as exc:
        store.log_event("provision_error", str(exc)[:300])


@asynccontextmanager
async def lifespan(_: FastAPI):
    store.init()
    server.attach_notifier(bot.notify)
    bot.start()
    server.start_idle_monitor()
    if config.WAKE_ON_BOOT:
        threading.Thread(target=server.wake, kwargs={"reason": "boot"}, daemon=True).start()
    if config.PROVISION_ON_BOOT:
        threading.Thread(target=_prefetch, name="prefetch", daemon=True).start()
    store.log_event("space", f"control plane up on :{config.CONTROL_PORT}")
    yield
    server.shutdown()
    bot.stop()


app = FastAPI(title=config.SERVER_NAME, version=config.VERSION, lifespan=lifespan,
              docs_url=None, redoc_url=None)


def _authorized(request: Request) -> bool:
    token = request.headers.get("x-admin-token") or request.query_params.get("token") or ""
    if token and token == config.ADMIN_TOKEN:
        return True
    client = request.client.host if request.client else ""
    return client in {"127.0.0.1", "::1", "localhost"}


def _payload() -> dict:
    status = server.status()
    status.update(
        {
            "max_players": config.MAX_PLAYERS,
            "events": store.events(12),
            "counters": store.counters(),
            "public_address": config.MC_PUBLIC_ADDRESS or None,
            "bedrock_address": config.BEDROCK_PUBLIC_ADDRESS or None,
            "telegram": bot.enabled,
            "space_url": config.SPACE_URL,
            "idle_sleep_minutes": config.IDLE_MINUTES,
            "data_dir": str(config.DATA_DIR),
            "crossplay": config.CROSSPLAY,
            "education": {
                "enabled": config.EDU_ENABLED,
                "connection_id": provision.edu_connection_id() if config.EDU_ENABLED else "",
            },
        }
    )
    return status


@app.get("/", response_class=HTMLResponse)
async def index() -> str:
    return dashboard.render(config.SERVER_NAME, config.VERSION, config.IDLE_MINUTES)


@app.get("/start", response_class=HTMLResponse)
async def player_page() -> str:
    """The only page players get: one button, the address, no controls."""
    return dashboard.render_start(config.SERVER_NAME, config.VERSION,
                                 config.MC_PUBLIC_ADDRESS)


@app.get("/health")
async def health() -> JSONResponse:
    """UptimeRobot target. 200 means the Space is alive, not that MC is awake."""
    payload = {"status": "ok", "minecraft": server.state, "version": config.VERSION}
    return JSONResponse(payload, status_code=200)


@app.get("/api/status")
async def api_status() -> dict:
    return _payload()


@app.get("/api/events")
async def api_events(limit: int = 25) -> dict:
    return {"events": store.events(limit)}


@app.get("/api/logs")
async def api_logs(lines: int = 60) -> dict:
    tail = list(server.log_tail)[-max(1, min(lines, 300)):]
    return {"lines": tail}


@app.post("/api/wake")
async def api_wake(request: Request) -> dict:
    reason = request.query_params.get("reason", "http")
    store.log_event("http", f"wake via {request.client.host if request.client else '?'}")
    return server.wake(reason=reason)


@app.post("/api/sleep")
async def api_sleep(request: Request) -> JSONResponse:
    if not _authorized(request):
        return JSONResponse({"error": "admin token required"}, status_code=401)
    return JSONResponse(server.sleep(reason="http"))


@app.post("/internal/wake")
async def internal_wake(request: Request) -> JSONResponse:
    """Called by the wake proxy when a player connects; loopback only."""
    if not _authorized(request):
        return JSONResponse({"error": "forbidden"}, status_code=403)
    return JSONResponse(server.wake(reason="player-join"))


@app.get("/api/config")
async def api_config() -> dict:
    return config.summary()


@app.get("/robots.txt", response_class=HTMLResponse)
async def robots() -> str:
    return "User-agent: *\nDisallow: /\n"
