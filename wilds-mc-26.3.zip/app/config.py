"""Runtime configuration for the Minecraft 26.3 Space.

Secrets that the user does not provide are generated once and stored in
DATA_DIR so they survive restarts (when DATA_DIR is a mounted bucket).
"""
from __future__ import annotations

import os
import re
import secrets
from pathlib import Path

VERSION = os.environ.get("MC_VERSION", "26.3")
PROTOCOL = int(os.environ.get("MC_PROTOCOL", "777"))


def env(name: str, default: str = "") -> str:
    value = os.environ.get(name)
    return default if value is None else value.strip()


def _resolve_data_dir() -> Path:
    candidates: list[Path] = []
    raw = env("DATA_DIR")
    if raw:
        candidates.append(Path(raw))
    candidates.append(Path("/data") if os.name != "nt" else Path.cwd() / "data")
    candidates.append(Path.cwd() / "data")
    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            probe = candidate / ".write-probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink()
            return candidate.resolve()
        except OSError:
            continue
    return Path.cwd().resolve()


DATA_DIR = _resolve_data_dir()
SERVER_DIR = DATA_DIR / "server"
PLUGIN_DIR = SERVER_DIR / "plugins"
LOG_DIR = DATA_DIR / "logs"
for _directory in (SERVER_DIR, PLUGIN_DIR, LOG_DIR):
    _directory.mkdir(parents=True, exist_ok=True)

# Networking: the public TCP port is held by the wake proxy; Paper listens on a
# private port behind it so a sleeping server can still answer status pings.
PUBLIC_PORT = int(env("PUBLIC_PORT", "25565"))
SERVER_PORT = int(env("SERVER_PORT", "25566"))
RCON_PORT = int(env("RCON_PORT", "25575"))
BEDROCK_PORT = int(env("BEDROCK_PORT", "19132"))
CONTROL_PORT = int(env("CONTROL_PORT", "7860"))

MC_MEMORY = env("MC_MEMORY", "4G")
MC_MIN_MEMORY = env("MC_MIN_MEMORY", "1G")
MAX_PLAYERS = int(env("MAX_PLAYERS", "20"))
# Player-facing name. SERVER_NAME is the single place to rebrand: the MOTD, the
# /start page and the dashboard all read it.
SERVER_NAME = env("SERVER_NAME", "Trust Republic SMP")
MOTD = env("MC_MOTD", SERVER_NAME)
BEDROCK_MOTD = env("MC_BEDROCK_MOTD", f"{SERVER_NAME} (Bedrock)")

# Crossplay mode.
#   "bedrock" - upstream Geyser + Floodgate (Java + Bedrock)
#   "edu"     - EduGeyser + EduFloodgate: one Geyser fork that also speaks
#               NetherNet, so Education Edition clients join the same world.
# Education is on by default because the fork still serves regular Bedrock.
# Opt out with CROSSPLAY=bedrock or EDU_ENABLED=false.
CROSSPLAY = env(
    "CROSSPLAY",
    "bedrock" if env("EDU_ENABLED").lower() in {"0", "false", "no", "off"} else "edu",
).lower()
if CROSSPLAY not in {"bedrock", "edu"}:
    CROSSPLAY = "bedrock"
EDU_ENABLED = CROSSPLAY == "edu"

# Pinned because these forks are not on the GeyserMC download API; bumping is a
# one-line change here. EduGeyser 2.28.0-edu targets Java 26.3 and needs the
# EduFloodgate build below (its own release notes name this exact version).
EDUGEYSER_VERSION = env("EDUGEYSER_VERSION", "v2.28.0-edu")
EDUFLOODGATE_VERSION = env("EDUFLOODGATE_VERSION", "v2.2.5-edu.13")
EDU_CONNECTION_ID = env("EDU_CONNECTION_ID")
EDUGEYSER_URL = (
    "https://codeberg.org/SendableMetatype/EduGeyser/releases/download/"
    f"{EDUGEYSER_VERSION}/EduGeyser-Spigot.jar"
)
EDUFLOODGATE_URL = (
    "https://github.com/EduGeyser/EduFloodgate/releases/download/"
    f"{EDUFLOODGATE_VERSION}/edufloodgate-spigot.jar"
)

# Recipes are server-owned since 1.21.2: the client only receives the ones it
# has unlocked, which is why JEI shows nothing on a plain Paper server. Granting
# every recipe to every player fills the vanilla recipe book and is the only
# part of this that needs no plugin at all.
UNLOCK_ALL_RECIPES = env("UNLOCK_ALL_RECIPES", "true").lower() in {"1", "true", "yes", "on"}


def _extra_plugins() -> list[tuple[str, str]]:
    """Paper plugins to install beside Geyser, as (filename, url) pairs.

    `EXTRA_PLUGINS` takes comma- or newline-separated entries, either a bare jar
    URL (`https://.../ServerWaypoint.jar`) or `name.jar=https://...`. Paper only
    loads Bukkit plugins from plugins/; Fabric/NeoForge mods such as JEI and
    Xaero's Minimap are client-side and belong nowhere near this list.
    """
    entries: list[tuple[str, str]] = []
    for raw in re.split(r"[,\n]", env("EXTRA_PLUGINS")):
        item = raw.strip()
        if not item:
            continue
        name, _, url = item.partition("=")
        if not url:
            name, url = "", name
        url = url.strip()
        if not url.startswith(("https://", "http://")):
            continue
        name = name.strip() or url.split("?")[0].rstrip("/").rsplit("/", 1)[-1]
        if not name.lower().endswith(".jar"):
            name += ".jar"
        name = re.sub(r"[^A-Za-z0-9._-]", "_", name)
        entries.append((name, url))
    return entries


EXTRA_PLUGINS = _extra_plugins()

IDLE_MINUTES = float(env("IDLE_SLEEP_MINUTES", "10"))


def _num(name: str, default: float) -> float:
    try:
        return float(env(name, str(default)) or default)
    except ValueError:
        return default


# Host run limits. InstaBox pauses a free machine after 480 running minutes, and
# a pause freezes the JVM rather than stopping it, so the world is closed from
# inside this many minutes in: RUN_CAP_MINUTES minus the margin. 0 disables it.
RUN_CAP_MINUTES = _num("RUN_CAP_MINUTES", 0)
RUN_CAP_MARGIN_MINUTES = _num("RUN_CAP_MARGIN_MINUTES", 8)
# Start Paper as soon as the control plane is up (used by scheduled hosts, where
# the machine only exists during a known window).
WAKE_ON_BOOT = env("WAKE_ON_BOOT", "false").lower() in {"1", "true", "yes", "on"}
AUTO_SLEEP = env("AUTO_SLEEP", "true").lower() in {"1", "true", "yes", "on"}
WAKE_TIMEOUT = int(env("WAKE_TIMEOUT_SECONDS", "420"))
PROVISION_ON_BOOT = env("PROVISION_ON_BOOT", "true").lower() in {"1", "true", "yes", "on"}

TELEGRAM_TOKEN = env("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = env("TELEGRAM_CHAT_ID")


def _backup_hours() -> float:
    """Default to a daily-ish snapshot only when a bot token actually exists."""
    raw = env("TELEGRAM_BACKUP_HOURS", "12" if TELEGRAM_TOKEN else "0")
    try:
        return max(0.0, float(raw)) if raw else 0.0
    except ValueError:
        return 0.0


TELEGRAM_BACKUP_HOURS = _backup_hours()
HEARTBEAT_URL = env("UPTIMEROBOT_HEARTBEAT_URL")
MC_PUBLIC_ADDRESS = env("MC_PUBLIC_ADDRESS")
BEDROCK_PUBLIC_ADDRESS = env("BEDROCK_PUBLIC_ADDRESS")
SPACE_URL = env("SPACE_PUBLIC_URL", f"http://127.0.0.1:{CONTROL_PORT}")


def _persisted_secret(filename: str, provided: str) -> str:
    if provided:
        return provided
    path = DATA_DIR / filename
    try:
        if path.exists():
            existing = path.read_text(encoding="utf-8").strip()
            if existing:
                return existing
        generated = secrets.token_urlsafe(24)
        path.write_text(generated + "\n", encoding="utf-8")
        return generated
    except OSError:
        return secrets.token_urlsafe(24)


RCON_PASSWORD = _persisted_secret("rcon.pass", env("RCON_PASSWORD"))
ADMIN_TOKEN = _persisted_secret("admin.token", env("ADMIN_TOKEN"))
DB_PATH = DATA_DIR / "state.db"
CONSOLE_LOG = LOG_DIR / "console.log"


def summary() -> dict:
    """Non-secret settings that the dashboard and Telegram may show."""
    return {
        "version": VERSION,
        "protocol": PROTOCOL,
        "public_port": PUBLIC_PORT,
        "server_port": SERVER_PORT,
        "bedrock_port": BEDROCK_PORT,
        "control_port": CONTROL_PORT,
        "max_players": MAX_PLAYERS,
        "motd": MOTD,
        "auto_sleep": AUTO_SLEEP,
        "idle_sleep_minutes": IDLE_MINUTES,
        "java_memory": MC_MEMORY,
        "java_min_memory": MC_MIN_MEMORY,
        "data_dir": str(DATA_DIR),
        "telegram_enabled": bool(TELEGRAM_TOKEN),
        "crossplay": CROSSPLAY,
        "education_enabled": EDU_ENABLED,
        "unlock_all_recipes": UNLOCK_ALL_RECIPES,
        "extra_plugins": [name for name, _ in EXTRA_PLUGINS],
        "run_cap_minutes": RUN_CAP_MINUTES,
        "run_cap_margin_minutes": RUN_CAP_MARGIN_MINUTES,
        "wake_on_boot": WAKE_ON_BOOT,
        "playit_enabled": bool(env("PLAYIT_SECRET")),
        "uptimerobot_heartbeat": bool(HEARTBEAT_URL),
        "server_name": SERVER_NAME,
        "public_address": MC_PUBLIC_ADDRESS,
        "bedrock_address": BEDROCK_PUBLIC_ADDRESS,
        "space_url": SPACE_URL,
    }
